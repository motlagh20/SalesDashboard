import mysql from "mysql2/promise";
import Redis from "ioredis";
import fs from "fs";
import path from "path";
import { DEFAULT_PASSWORD_BCRYPT_HASH, isBcryptHash, hashPasswordSync, migrateDatabasePasswords, generateTemporaryPassword, isDefaultPassword, isDefaultPasswordOrMatches } from "./password";

// Lazy connection instances
let pool: mysql.Pool | null = null;
let redis: Redis | null = null;

// Active error logging path
// Active error logging path and size constraints
const LOG_FILE_PATH = path.join(process.cwd(), "server", "db_errors.log");
const MAX_LOG_SIZE_BYTES = 2 * 1024 * 1024; // 2 MB bound

/**
 * Rotates the database error log file if its size exceeds the specified limit.
 * Keeps at most 1 rotated backup file (db_errors.log.1) to bound disk usage.
 */
export function rotateLogFileIfNeeded(filePath: string = LOG_FILE_PATH, maxBytes: number = MAX_LOG_SIZE_BYTES): boolean {
  try {
    if (!fs.existsSync(filePath)) return false;
    const stats = fs.statSync(filePath);
    if (stats.size >= maxBytes) {
      const backupPath = `${filePath}.1`;
      try {
        if (fs.existsSync(backupPath)) {
          fs.unlinkSync(backupPath);
        }
      } catch {}
      try {
        fs.renameSync(filePath, backupPath);
      } catch {
        fs.truncateSync(filePath, 0);
      }
      return true;
    }
  } catch {}
  return false;
}

const SENSITIVE_LOG_KEY_REGEX = /pass(word)?|pwd|secret|api[-_]?key|token|otp|code|auth(orization)?|cookie|credential/i;

function redactSensitiveData(value: any, depth = 0): any {
  if (depth > 8 || value === null || value === undefined) return value;
  if (typeof value === "string") {
    return value
      .replace(/(Bearer\s+)[A-Za-z0-9._\-+/=]+/gi, "$1[REDACTED]")
      .replace(/((?:smtpPassword|apiKey|password|recoveryToken|token|otp|code)["']?\s*[:=]\s*["']?)[^"',\s}]+/gi, "$1[REDACTED]");
  }
  if (Array.isArray(value)) {
    return value.map((item) => redactSensitiveData(item, depth + 1));
  }
  if (typeof value === "object") {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(value)) {
      if (SENSITIVE_LOG_KEY_REGEX.test(k)) {
        out[k] = "[REDACTED]";
      } else {
        out[k] = redactSensitiveData(v, depth + 1);
      }
    }
    return out;
  }
  return value;
}

/**
 * Writes detailed database/server errors to a persistent log file in the workspace
 * with bounded log rotation to prevent unbounded disk growth.
 */
export function writeServerErrorLog(operation: string, error: any, reqBody?: any) {
  try {
    // Skip expected or non-critical error noise
    if (!error || error.code === 'ER_DUP_ENTRY' || error.name === 'AbortError' || error.message?.includes('aborted')) {
      return;
    }

    rotateLogFileIfNeeded(LOG_FILE_PATH, MAX_LOG_SIZE_BYTES);

    const timestamp = new Date().toISOString();
    const safeReqBody = reqBody !== undefined ? redactSensitiveData(reqBody) : undefined;
    const safeMessage = redactSensitiveData(error?.message || "No message");
    const safeStack = redactSensitiveData(error?.stack || "No stack trace available");
    const errorDetails = {
      timestamp,
      operation,
      message: safeMessage,
      code: error?.code || null,
      errno: error?.errno || null,
      sql: error?.sql || null,
      sqlState: error?.sqlState || null,
      stack: safeStack,
      requestBody: safeReqBody !== undefined ? JSON.stringify(safeReqBody) : "None"
    };

    const logLine = `[${timestamp}] [${operation}]
Message: ${errorDetails.message}
Code: ${errorDetails.code} | ErrNo: ${errorDetails.errno} | SqlState: ${errorDetails.sqlState}
SQL Executed: ${errorDetails.sql || "N/A"}
Request Body: ${errorDetails.requestBody}
Stack Trace: ${errorDetails.stack}
----------------------------------------------------------------------\n`;

    fs.mkdirSync(path.dirname(LOG_FILE_PATH), { recursive: true });
    fs.appendFileSync(LOG_FILE_PATH, logLine, "utf8");
  } catch {
    // Silently continue without blocking execution
  }
}

/**
 * Detects whether the server is running in a production environment.
 */
export function isProductionEnvironment(): boolean {
  const env = (process.env.NODE_ENV || "").toLowerCase().trim();
  const appEnv = (process.env.APP_ENV || "").toLowerCase().trim();
  return env === "production" || appEnv === "production";
}

/**
 * Controlled database maintenance error for production outages.
 */
export class DatabaseMaintenanceError extends Error {
  public statusCode: number = 503;
  public isPublic: boolean = true;
  constructor(message = "Database service is temporarily unavailable for maintenance. Please try again shortly.") {
    super(message);
    this.name = "DatabaseMaintenanceError";
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}

/**
 * Determines whether a given database error indicates network, connection, or service outage.
 */
export function isConnectionError(err: any): boolean {
  if (!err) return false;
  if (err instanceof DatabaseMaintenanceError) return true;
  const code = err.code || err.errno;
  const connectionCodes = [
    "ECONNREFUSED",
    "PROTOCOL_CONNECTION_LOST",
    "ETIMEDOUT",
    "EHOSTUNREACH",
    "ENETUNREACH",
    "ER_SERVER_SHUTDOWN",
    "ER_CON_COUNT_ERROR",
    "ER_ACCESS_DENIED_ERROR",
    "ER_BAD_DB_ERROR",
    "POOL_CLOSED",
    "POOL_ENQUEUELIMIT",
    "PROTOCOL_ENQUEUE_AFTER_FATAL_ERROR",
    "EPIPE",
    "ECONNRESET"
  ];
  if (typeof code === "string" && connectionCodes.includes(code)) return true;
  if (typeof err.message === "string") {
    const msg = err.message.toLowerCase();
    if (
      msg.includes("connection lost") ||
      msg.includes("econnrefused") ||
      msg.includes("etimedout") ||
      msg.includes("server shutdown") ||
      msg.includes("maintenance mode") ||
      msg.includes("cannot enqueue") ||
      msg.includes("pool is closed") ||
      msg.includes("econnreset")
    ) {
      return true;
    }
  }
  return false;
}

// Database state & failover guards
let isDbHealthy = false;
let dbMaintenanceError: DatabaseMaintenanceError | null = null;
let isFallbackMode = false;
let mockPoolInstance: MockPool | null = null;
let recoveryProbeTimer: NodeJS.Timeout | null = null;
let isProbing = false;
const JSON_FILE_PATH = path.join(process.cwd(), "server", "salesdashboard.json");

export function markDatabaseHealthy() {
  const wasUnhealthy = !isDbHealthy;
  isDbHealthy = true;
  dbMaintenanceError = null;
  if (wasUnhealthy) {
    console.log("✅ [Database Recovery] MariaDB connectivity active and healthy.");
  }
  stopRecoveryProbe();
}

export function markDatabaseUnhealthy(err?: any) {
  const wasHealthy = isDbHealthy;
  isDbHealthy = false;
  dbMaintenanceError = new DatabaseMaintenanceError(
    "Database service is temporarily unavailable for maintenance. Please try again shortly."
  );
  if (wasHealthy) {
    console.warn("⚠️ [Database Outage] MariaDB is marked UNHEALTHY. Entering maintenance mode.");
  }
  startRecoveryProbe();
}

function startRecoveryProbe() {
  if (recoveryProbeTimer) return;
  // Bounded recovery probe: checks connectivity every 3 seconds without flooding MariaDB
  recoveryProbeTimer = setInterval(async () => {
    if (isProbing) return;
    isProbing = true;
    try {
      if (!pool) return;
      await Promise.race([
        pool.query("SELECT 1"),
        new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), 2000))
      ]);
      markDatabaseHealthy();
    } catch {
      // Still unreachable, wait for next cycle
    } finally {
      isProbing = false;
    }
  }, 3000);
  if (recoveryProbeTimer.unref) {
    recoveryProbeTimer.unref();
  }
}

function stopRecoveryProbe() {
  if (recoveryProbeTimer) {
    clearInterval(recoveryProbeTimer);
    recoveryProbeTimer = null;
  }
}

export function isDatabaseHealthy(): boolean {
  if (isProductionEnvironment()) {
    return isDbHealthy;
  }
  if (isFallbackMode) {
    return true; // Local dev mock database is active
  }
  return isDbHealthy;
}

export async function checkDatabaseHealth(): Promise<boolean> {
  if (!isProductionEnvironment() && isFallbackMode) {
    return true;
  }
  try {
    const rawPool = pool || ensurePoolInitialized();
    await Promise.race([
      rawPool.query("SELECT 1"),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Database health ping timed out")), 2000)
      )
    ]);
    markDatabaseHealthy();
    return true;
  } catch (err: any) {
    markDatabaseUnhealthy(err);
    return false;
  }
}

export function isFallbackModeActive(): boolean {
  return isFallbackMode;
}

// Testing overrides and state resets
export function setDbHealthyForTesting(healthy: boolean) {
  isDbHealthy = healthy;
  if (!healthy) {
    dbMaintenanceError = new DatabaseMaintenanceError();
  } else {
    dbMaintenanceError = null;
  }
}

export function setDbPoolForTesting(overridePool: any) {
  pool = overridePool;
}

export function resetDatabaseStateForTesting() {
  isDbHealthy = false;
  dbMaintenanceError = null;
  isFallbackMode = false;
  mockPoolInstance = null;
  stopRecoveryProbe();
  pool = null;
}

// In-memory persistent object cache to eliminate sync disk I/O on every single query
let inMemoryJsonDataCache: any = null;
let saveDebounceTimer: NodeJS.Timeout | null = null;

function loadJsonData(): any {
  if (isProductionEnvironment()) {
    throw new DatabaseMaintenanceError("Access to local JSON fallback database is strictly forbidden in production. Database is in maintenance mode.");
  }
  if (inMemoryJsonDataCache) {
    return inMemoryJsonDataCache;
  }
  if (!fs.existsSync(JSON_FILE_PATH)) {
    const initial = {
      products: [],
      agents: [],
      shipping_companies: [],
      orders: [],
      order_history: [],
      app_users: [],
      permanent_drivers: []
    };
    fs.mkdirSync(path.dirname(JSON_FILE_PATH), { recursive: true });
    fs.writeFileSync(JSON_FILE_PATH, JSON.stringify(initial, null, 2), "utf8");
    inMemoryJsonDataCache = initial;
    return initial;
  }
  try {
    const raw = fs.readFileSync(JSON_FILE_PATH, "utf8");
    const parsed = JSON.parse(raw);
    if (!parsed.app_users) parsed.app_users = [];
    if (!parsed.permanent_drivers) parsed.permanent_drivers = [];
    inMemoryJsonDataCache = parsed;
    return parsed;
  } catch (err) {
    console.error("Error reading fallback JSON database:", err);
    inMemoryJsonDataCache = {
      products: [],
      agents: [],
      shipping_companies: [],
      orders: [],
      order_history: [],
      app_users: [],
      permanent_drivers: []
    };
    return inMemoryJsonDataCache;
  }
}

function saveJsonData(data: any, immediate: boolean = false) {
  // Requirement 1: Prevent automatic production writes to JSON storage
  if (isProductionEnvironment()) {
    const errorMsg = "Production writes to local JSON storage are forbidden to protect data consistency. Database is in maintenance mode.";
    console.error(`🚨 [Database Guard] ${errorMsg}`);
    writeServerErrorLog("saveJsonData (Production Guard)", new Error(errorMsg));
    throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
  }

  inMemoryJsonDataCache = data;
  
  const performWrite = () => {
    try {
      fs.mkdirSync(path.dirname(JSON_FILE_PATH), { recursive: true });
      fs.writeFileSync(JSON_FILE_PATH, JSON.stringify(data, null, 2), "utf8");
    } catch (err) {
      console.error("Error writing fallback JSON database:", err);
    }
  };

  if (immediate) {
    if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
    performWrite();
  } else {
    if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
    saveDebounceTimer = setTimeout(performWrite, 100);
  }
}

function seedJsonIfEmpty() {
  if (isProductionEnvironment()) {
    return; // Requirement 2: Never seed or write to JSON storage in production
  }
  const data = loadJsonData();
  let changed = false;

  if (!data.products || data.products.length === 0) {
    console.log("🌱 [Mock Seed] Seeding default products...");
    data.products = [
      { id: 'prod-1', name: 'سفال سقف طبرستان (طرح کلاسیک)', category: 'roofing', pricePerUnit: 145000, unit: 'عدد', description: 'مقاومت بسیار بالا در برابر تغییرات جوی و یخبندان، عایق حرارتی و رطوبتی فوق‌العاده با لعاب طبیعی.', weight: '۳.۱ کیلوگرم', dimensions: '۳۰ × ۴۲ سانتی‌متر', coverageInfo: '۱۴ عدد در هر مترمربع', isEnabled: 1, imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=150&auto=format&fit=crop&q=80' },
      { id: 'prod-2', name: 'آجر سفال ۱۰ سانتی طبرستان (تیغه)', category: 'bricks', pricePerUnit: 3400, unit: 'قالب', description: 'جهت دیوارهای داخلی و فضاهای کم‌عرض، پخت با کوره تمام اتوماتیک هافمن و ابعاد کاملاً گونیا.', weight: '۲.۲ کیلوگرم', dimensions: '۱۰ × ۲۰ × ۲۰ سانتی‌متر', coverageInfo: '۲۵ قالب در هر مترمربع تیغه', isEnabled: 1, imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=150&auto=format&fit=crop&q=80' },
      { id: 'prod-3', name: 'آجر سفال ۱۵ سانتی درجه یک طبرستان', category: 'bricks', pricePerUnit: 4800, unit: 'قالب', description: 'بهترین گزینه برای دیوارهای خارجی باغ، ویلا و آپارتمان جهت عایق‌بندی صوتی و حرارتی پیشرفته.', weight: '۳.۳ کیلوگرم', dimensions: '۱۵ × ۲۰ × ۲۰ سانتی‌متر', coverageInfo: '۲۵ قالب در هر مترمربع دیوار', isEnabled: 1, imageUrl: 'https://images.unsplash.com/photo-1590069261209-f8e9b8642343?w=150&auto=format&fit=crop&q=80' },
      { id: 'prod-4', name: 'آجر نما نسوز سموتی طبرستان', category: 'facade', pricePerUnit: 12500, unit: 'قالب', description: 'مقاومت حرارتی بیش از ۱۲۰۰ درجه سانتی‌گراد، رنگ ثابت و مقاوم در برابر باران‌های اسیدی و شوره‌زدگی.', weight: '۰.۸ کیلوگرم', dimensions: '۵.۵ × ۲.۵ × ۲۶ سانتی‌متر', coverageInfo: '۴۰ قالب در هر مترمربع با بندکشی', isEnabled: 1, imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=150&auto=format&fit=crop&q=80' },
      { id: 'prod-5', name: 'تیغه سفال سقفی ۲۵ طبرستان (بلوک سقفی)', category: 'bricks', pricePerUnit: 9500, unit: 'قالب', description: 'تولید شده با رس مرغوب شسته شده، مقاومت فشاری بالا و ایده آل برای سقف‌های تیرچه بلوک صنعتی.', weight: '۷.۵ کیلوگرم', dimensions: '۲۵ × ۲۰ × ۴۰ سانتی‌متر', coverageInfo: '۱۰ قالب در هر مترمربع سقف', isEnabled: 1, imageUrl: 'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b2?w=150&auto=format&fit=crop&q=80' }
    ];
    changed = true;
  }

  if (!data.agents || data.agents.length === 0) {
    console.log("🌱 [Mock Seed] Seeding default agents...");
    data.agents = [
      { id: 'ag-1', fullName: 'آقای حمیدرضا احمدی', alias: 'نمایندگی تهران (احمدی)', agentCode: 'AG-9081', phoneNumber: '09121111111', address: 'تهران، ابتدای جاده قدیم کرج، مجتمع تجاری پایتخت، پلاک ۱۲', area: 'کل استان تهران؛ کل استان البرز', territories: [{ province: 'تهران', allCities: true }, { province: 'البرز', allCities: true }], isExportAgent: true, isEnabled: 1 },
      { id: 'ag-2', fullName: 'آقای علیرضا رجایی', alias: 'نمایندگی اصفهان (رجایی)', agentCode: 'AG-6055', phoneNumber: '09132222222', address: 'اصفهان، بلوار فرودگاه، نرسیده به شهرک صنعتی جی، پلاک ۴۶', area: 'کل استان اصفهان؛ کل استان یزد', territories: [{ province: 'اصفهان', allCities: true }, { province: 'یزد', allCities: true }], isExportAgent: false, isEnabled: 1 },
      { id: 'ag-3', fullName: 'آقای سهراب پوربخش', alias: 'نمایندگی رشت (پوربخش)', agentCode: 'AG-2019', phoneNumber: '09113333333', address: 'گیلان، رشت، کیلومتر ۵ جاده انزلی، جنب انبار فومن‌شیمی', area: 'کل استان گیلان؛ کل استان مازندران', territories: [{ province: 'گیلان', allCities: true }, { province: 'مازندران', allCities: true }], isExportAgent: false, isEnabled: 1 },
      { id: 'ag-4', fullName: 'آقای کریم نمازی', alias: 'نمایندگی شیراز (نمازی)', agentCode: 'AG-7023', phoneNumber: '09174444444', address: 'فارس، شیراز، بلوار امیرکبیر، روبروی باغ جنت، مجتمع سفال', area: 'کل استان فارس؛ کل استان بوشهر', territories: [{ province: 'فارس', allCities: true }, { province: 'بوشهر', allCities: true }], isExportAgent: false, isEnabled: 1 }
    ];
    changed = true;
  }

  if (!data.shipping_companies || data.shipping_companies.length === 0) {
    console.log("🌱 [Mock Seed] Seeding default shipping companies...");
    data.shipping_companies = [
      { id: 'sc-1', name: 'باربری ترانزیت طبرستان', code: 'SC-101', phoneNumber: '01133334444', managerName: 'آقای صالحی', address: 'ساری، کیلومتر ۳ جاده فیروزکوه، پایانه باربری ترانزیت', isEnabled: 1 },
      { id: 'sc-2', name: 'باربری زاینده‌رود طبرستان', code: 'SC-102', phoneNumber: '01133335555', managerName: 'آقای صادقی', address: 'اصفهان، شهرک صنعتی جی، خیابان چهارم، پایانه باربری زاینده‌رود', isEnabled: 1 },
      { id: 'sc-3', name: 'اتوبار کاسپین طبرستان', code: 'SC-103', phoneNumber: '01133336666', managerName: 'آقای احمدی', address: 'رشت، جاده انزلی، جنب پایانه حمل و نقل کاسپین', isEnabled: 1 }
    ];
    changed = true;
  }

  if (!data.permanent_drivers || data.permanent_drivers.length === 0) {
    console.log("🌱 [Mock Seed] Seeding default permanent drivers...");
    data.permanent_drivers = [
      { id: 'drv-1', driverName: 'کریم قنبری', driverPhone: '09117772222', licensePlate: '۵۴ ع ۸۹۲ ایران ۷۲', vehicleType: 'تریلی ۱۸ چرخ لبه‌دار', shippingAgency: 'باربری ترانزیت شمال', shippingCompanyId: null, nationalCode: '2081234567', smartCardNumber: '3849201', isEnabled: 1 },
      { id: 'drv-2', driverName: 'غلامرضا صادقی', driverPhone: '09139998888', licensePlate: '۷۲ ب ۵۵۱ ایران ۵۳', vehicleType: 'کامیون جفت ۱۰ تن', shippingAgency: 'باربری زاینده‌رود طبرستان', shippingCompanyId: 'sc-2', nationalCode: '1289876543', smartCardNumber: '4920183', isEnabled: 1 },
      { id: 'drv-3', driverName: 'مرتضی حسینی', driverPhone: '09112223344', licensePlate: '۳۶ ج ۱۴۵ ایران ۶۲', vehicleType: 'خاور مسقف', shippingAgency: 'اتوبار کاسپین طبرستان', shippingCompanyId: 'sc-3', nationalCode: '2093344556', smartCardNumber: '1092837', isEnabled: 1 },
      { id: 'drv-4', driverName: 'جواد علوی', driverPhone: '09112523456', licensePlate: '۶۲ ع ۴۸۱ ایران ۷۲', vehicleType: 'تریلی ۱۸ چرخ لبه‌دار', shippingAgency: 'باربری ترانزیت طبرستان', shippingCompanyId: 'sc-1', nationalCode: '2089988771', smartCardNumber: '5544332', isEnabled: 1 }
    ];
    changed = true;
  }

  if (!data.orders) {
    data.orders = [];
    changed = true;
  }
  if (!data.order_history) {
    data.order_history = [];
    changed = true;
  }

  const ADMIN_SECURE_PASSWORD_HASH = "$2b$10$PsDANqVXkW9r/PZuHcEKzOQBvPNYbYeFU/D4WMt3fBE0mH2U4x33a";

  if (!data.app_users || data.app_users.length === 0) {
    console.log("🌱 [Mock Seed] Seeding default app users...");
    data.app_users = [
      { id: 'usr-0', username: 'admin', fullName: 'ادمین ارشد نرم‌افزار', phoneNumber: '09120000000', role: 'SYSTEM_ADMIN', agentCode: null, shippingCompanyId: null, isEnabled: 1, password: ADMIN_SECURE_PASSWORD_HASH, mustChangePassword: 0 },
      { id: 'usr-1', username: 'manager', fullName: 'آقای احمدی (مدیر بازرگانی)', phoneNumber: '09121111111', role: 'SALES_MANAGER', agentCode: null, shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-2', username: 'rep_tehran', fullName: 'آقای حمیدرضا احمدی', phoneNumber: '09120000001', role: 'REPRESENTATIVE', agentCode: 'AG-9081', shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-3', username: 'rep_esfahan', fullName: 'آقای علیرضا رجایی', phoneNumber: '09130000002', role: 'REPRESENTATIVE', agentCode: 'AG-6055', shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-4', username: 'rep_rasht', fullName: 'آقای سهراب پوربخش', phoneNumber: '09110000003', role: 'REPRESENTATIVE', agentCode: 'AG-2019', shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-5', username: 'rep_shiraz', fullName: 'آقای کریم نمازی', phoneNumber: '09170000004', role: 'REPRESENTATIVE', agentCode: 'AG-7023', shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-6', username: 'factory', fullName: 'مسئول فروش کارخانه', phoneNumber: '09110000005', role: 'FACTORY_TRANSPORT', agentCode: null, shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-7', username: 'shipping_transit', fullName: 'باربری ترانزیت طبرستان', phoneNumber: '09110000006', role: 'SHIPPING_COMPANY', agentCode: null, shippingCompanyId: 'sc-1', isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-72', username: 'shipping_zayandeh', fullName: 'باربری زاینده‌رود طبرستان', phoneNumber: '09130000007', role: 'SHIPPING_COMPANY', agentCode: null, shippingCompanyId: 'sc-2', isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-8', username: 'warehouse', fullName: 'مسئول انبار محصول (بارگیری و صدور حواله)', phoneNumber: '09110000008', role: 'PRODUCT_WAREHOUSE', agentCode: null, shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH },
      { id: 'usr-9', username: 'security_gate', fullName: 'افسر انتظامات و حراست گیت خروج', phoneNumber: '09110000009', role: 'SECURITY_GATE', agentCode: null, shippingCompanyId: null, isEnabled: 1, password: DEFAULT_PASSWORD_BCRYPT_HASH }
    ];
    changed = true;
  } else {
    // Ensure SYSTEM_ADMIN (admin) exists even if app_users already had data
    const hasAdmin = data.app_users.some((u: any) => u.username === 'admin' || u.role === 'SYSTEM_ADMIN' || u.phoneNumber === '09120000000');
    if (!hasAdmin) {
      console.log("🛡️ [Mock Seed] Auto-inserting missing SYSTEM_ADMIN (admin) user...");
      data.app_users.unshift({
        id: 'usr-0',
        username: 'admin',
        fullName: 'ادمین ارشد نرم‌افزار',
        phoneNumber: '09120000000',
        role: 'SYSTEM_ADMIN',
        agentCode: null,
        shippingCompanyId: null,
        isEnabled: 1,
        password: ADMIN_SECURE_PASSWORD_HASH,
        mustChangePassword: 0
      });
      changed = true;
    } else {
      const adminUser = data.app_users.find((u: any) => u.id === 'usr-0' || u.username === 'admin');
      if (adminUser && (adminUser.password === DEFAULT_PASSWORD_BCRYPT_HASH || isDefaultPasswordOrMatches(adminUser.password))) {
        adminUser.password = ADMIN_SECURE_PASSWORD_HASH;
        adminUser.mustChangePassword = 0;
        changed = true;
      }
    }

    // Ensure PRODUCT_WAREHOUSE exists
    const hasWarehouse = data.app_users.some((u: any) => u.username === 'warehouse' || u.role === 'PRODUCT_WAREHOUSE' || u.phoneNumber === '09110000008');
    if (!hasWarehouse) {
      console.log("📦 [Mock Seed] Auto-inserting missing PRODUCT_WAREHOUSE user...");
      data.app_users.push({
        id: 'usr-8',
        username: 'warehouse',
        fullName: 'مسئول انبار محصول (بارگیری و صدور حواله)',
        phoneNumber: '09110000008',
        role: 'PRODUCT_WAREHOUSE',
        agentCode: null,
        shippingCompanyId: null,
        isEnabled: 1,
        password: DEFAULT_PASSWORD_BCRYPT_HASH
      });
      changed = true;
    }

    // Ensure SECURITY_GATE exists
    const hasSecurity = data.app_users.some((u: any) => u.username === 'security_gate' || u.role === 'SECURITY_GATE' || u.phoneNumber === '09110000009');
    if (!hasSecurity) {
      console.log("👮 [Mock Seed] Auto-inserting missing SECURITY_GATE user...");
      data.app_users.push({
        id: 'usr-9',
        username: 'security_gate',
        fullName: 'افسر انتظامات و گیت حراست',
        phoneNumber: '09110000009',
        role: 'SECURITY_GATE',
        agentCode: null,
        shippingCompanyId: null,
        isEnabled: 1,
        password: DEFAULT_PASSWORD_BCRYPT_HASH
      });
      changed = true;
    }
  }

  if (changed) {
    saveJsonData(data);
  }
}

function executeQuery(sql: string, values: any[] = []): any {
  if (isProductionEnvironment()) {
    throw new DatabaseMaintenanceError("Mock query execution is strictly forbidden in production. Database is in maintenance mode.");
  }
  const cleanSql = sql.trim().replace(/\s+/g, " ");
  const jsonData = loadJsonData();

  if (/SELECT\s+1/i.test(cleanSql)) {
    return [[{ 1: 1 }], []];
  }

  // APP_USERS CUSTOM MOCK QUERIES
  if (/SELECT\s+.*?\s+FROM\s+app_users/i.test(cleanSql)) {
    const allUsers = jsonData.app_users || [];

    // 1. WHERE phoneNumber = ? AND id != ? (or id <> ?)
    if (/WHERE\s+phoneNumber\s*=\s*\?\s*AND\s*id\s*(?:!=|<>)\s*\?/i.test(cleanSql)) {
      const targetPhone = values[0] ? String(values[0]).trim().toLowerCase() : "";
      const excludeId = values[1] ? String(values[1]).trim() : "";
      const matched = allUsers.filter((u: any) =>
        u.phoneNumber && String(u.phoneNumber).trim().toLowerCase() === targetPhone &&
        String(u.id).trim() !== excludeId
      );
      return [matched, []];
    }

    // 2. WHERE (username = ? OR phoneNumber = ?) AND id != ?
    if (/WHERE\s*\(?\s*username\s*=\s*\?\s*OR\s*phoneNumber\s*=\s*\?\s*\)?\s*AND\s*id\s*(?:!=|<>)\s*\?/i.test(cleanSql)) {
      const uName = values[0] ? String(values[0]).trim().toLowerCase() : "";
      const phone = values[1] ? String(values[1]).trim().toLowerCase() : "";
      const excludeId = values[2] ? String(values[2]).trim() : "";
      const matched = allUsers.filter((u: any) =>
        ((u.username && String(u.username).trim().toLowerCase() === uName) ||
         (u.phoneNumber && String(u.phoneNumber).trim().toLowerCase() === phone)) &&
        String(u.id).trim() !== excludeId
      );
      return [matched, []];
    }

    // 2b. WHERE (LOWER(email) = LOWER(?) OR LOWER(username) = LOWER(?) OR phoneNumber = ?)
    if (/WHERE\s+\(?\s*(?:LOWER\()?email\)?\s*=\s*(?:LOWER\()?\?\)?\s*OR\s*(?:LOWER\()?username\)?\s*=\s*(?:LOWER\()?\?\)?\s*OR\s*phoneNumber\s*=\s*\?/i.test(cleanSql)) {
      const targetEmail = values[0] ? String(values[0]).trim().toLowerCase() : "";
      const targetUser = values[1] ? String(values[1]).trim().toLowerCase() : "";
      const targetPhone = values[2] ? String(values[2]).trim().toLowerCase() : "";
      const matched = allUsers.filter((u: any) =>
        (u.email && String(u.email).trim().toLowerCase() === targetEmail) ||
        (u.username && String(u.username).trim().toLowerCase() === targetUser) ||
        (u.phoneNumber && String(u.phoneNumber).trim().toLowerCase() === targetPhone)
      );
      return [matched, []];
    }

    // 3. WHERE username = ? OR phoneNumber = ?
    if (/WHERE\s+username\s*=\s*\?\s*OR\s*phoneNumber\s*=\s*\?/i.test(cleanSql)) {
      const uName = values[0] ? String(values[0]).trim().toLowerCase() : "";
      const phone = values[1] ? String(values[1]).trim().toLowerCase() : "";
      const matched = allUsers.filter((u: any) =>
        (u.username && String(u.username).trim().toLowerCase() === uName) ||
        (u.phoneNumber && String(u.phoneNumber).trim().toLowerCase() === phone)
      );
      return [matched, []];
    }

    // 4. WHERE id = ?
    if (/WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
      const targetId = values[0] ? String(values[0]).trim() : "";
      const matched = allUsers.filter((u: any) => u.id && String(u.id).trim() === targetId);
      return [matched, []];
    }

    // 5. WHERE username = ?
    if (/WHERE\s+username\s*=\s*\?/i.test(cleanSql)) {
      const uName = values[0] ? String(values[0]).trim().toLowerCase() : "";
      const matched = allUsers.filter((u: any) => u.username && String(u.username).trim().toLowerCase() === uName);
      return [matched, []];
    }

    // 6. WHERE phoneNumber = ?
    if (/WHERE\s+phoneNumber\s*=\s*\?/i.test(cleanSql)) {
      const phone = values[0] ? String(values[0]).trim().toLowerCase() : "";
      const matched = allUsers.filter((u: any) => u.phoneNumber && String(u.phoneNumber).trim().toLowerCase() === phone);
      return [matched, []];
    }

    // 6b. WHERE email = ? AND id != ?
    if (/WHERE\s+(?:LOWER\()?email\)?\s*=\s*(?:LOWER\()?\?\)?\s*AND\s*id\s*(?:!=|<>)\s*\?/i.test(cleanSql)) {
      const email = values[0] ? String(values[0]).trim().toLowerCase() : "";
      const excludeId = values[1] ? String(values[1]).trim() : "";
      const matched = allUsers.filter((u: any) =>
        u.email && String(u.email).trim().toLowerCase() === email && String(u.id).trim() !== excludeId
      );
      return [matched, []];
    }

    // 7. General search / fallback
    if (values && values.length > 0) {
      const searchTerms = values.map((v) => (v ? String(v).trim().toLowerCase() : ""));
      const matched = allUsers.filter((u: any) => {
        return searchTerms.some((term) => {
          if (!term) return false;
          return (
            (u.username && String(u.username).trim().toLowerCase() === term) ||
            (u.phoneNumber && String(u.phoneNumber).trim().toLowerCase() === term) ||
            (u.email && String(u.email).trim().toLowerCase() === term) ||
            (u.agentCode && String(u.agentCode).trim().toLowerCase() === term) ||
            (u.id && String(u.id).trim().toLowerCase() === term)
          );
        });
      });
      return [matched, []];
    }
    return [allUsers, []];
  }

  if (/INSERT\s+INTO\s+app_users/i.test(cleanSql)) {
    let id, username, fullName, phoneNumber, role, agentCode: any = null, shippingCompanyId: any = null, isEnabled: any = 1, email: string | null = null, emailVerified: any = 0, emailVerifiedAt: string | null = null, password: any, mustChangePassword: any = 0, tokenVersion: any = 0;
    const colsMatch = cleanSql.match(/INSERT\s+INTO\s+app_users\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)/i);
    if (colsMatch) {
      const colNames = colsMatch[1].split(",").map((c) => c.trim().replace(/[`"']/g, ""));
      const valTokens = colsMatch[2].split(",").map((t) => t.trim());
      let vIdx = 0;
      const mapped: Record<string, any> = {};
      colNames.forEach((col, i) => {
        const tok = valTokens[i];
        if (tok === "?") {
          mapped[col] = values[vIdx++];
        } else if (tok === "NULL" || tok === "null") {
          mapped[col] = null;
        } else if (tok === "0" || tok === "1") {
          mapped[col] = Number(tok);
        } else if (tok) {
          mapped[col] = tok.replace(/^['"]|['"]$/g, "");
        }
      });
      id = mapped.id;
      username = mapped.username;
      fullName = mapped.fullName;
      phoneNumber = mapped.phoneNumber;
      role = mapped.role || (/REPRESENTATIVE/i.test(cleanSql) ? "REPRESENTATIVE" : (/SHIPPING_COMPANY/i.test(cleanSql) ? "SHIPPING_COMPANY" : "USER"));
      agentCode = mapped.agentCode ?? null;
      shippingCompanyId = mapped.shippingCompanyId ?? null;
      isEnabled = mapped.isEnabled !== undefined ? mapped.isEnabled : 1;
      email = mapped.email ?? null;
      emailVerified = mapped.emailVerified !== undefined ? mapped.emailVerified : 0;
      emailVerifiedAt = mapped.emailVerifiedAt ?? null;
      password = mapped.password;
      mustChangePassword = mapped.mustChangePassword !== undefined ? mapped.mustChangePassword : 0;
      tokenVersion = mapped.tokenVersion !== undefined ? mapped.tokenVersion : 0;
    } else if (values.length === 11) {
      [id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, isEnabled, email, password, mustChangePassword] = values;
    } else if (values.length === 10) {
      if (/email/i.test(cleanSql)) {
        [id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, email, password, mustChangePassword] = values;
      } else {
        [id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, isEnabled, password, mustChangePassword] = values;
      }
    } else if (values.length === 9) {
      if (/mustChangePassword/i.test(cleanSql)) {
        [id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, password, mustChangePassword] = values;
      } else {
        [id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, isEnabled, password] = values;
      }
    } else if (values.length === 8) {
      [id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, password] = values;
    } else if (values.length === 6) {
      [id, username, fullName, phoneNumber, agentCode, password] = values;
      role = /REPRESENTATIVE/i.test(cleanSql) ? 'REPRESENTATIVE' : (/SHIPPING_COMPANY/i.test(cleanSql) ? 'SHIPPING_COMPANY' : 'USER');
      if (role === 'SHIPPING_COMPANY') {
        shippingCompanyId = agentCode;
        agentCode = null;
      }
      mustChangePassword = 1;
    }
    if (jsonData.app_users.some((u: any) => u.username === username || u.phoneNumber === phoneNumber)) {
      const err: any = new Error("Duplicate entry to users");
      err.code = "ER_DUP_ENTRY";
      err.errno = 1062;
      throw err;
    }
    let finalPassword = password;
    let finalMustChange = Number(mustChangePassword ?? 0);
    if (!finalPassword || isDefaultPassword(finalPassword)) {
      const tempPass = generateTemporaryPassword();
      finalPassword = hashPasswordSync(tempPass);
      finalMustChange = 1;
    } else if (!isBcryptHash(finalPassword)) {
      finalPassword = hashPasswordSync(finalPassword);
    }

    jsonData.app_users.push({
      id,
      username,
      fullName,
      phoneNumber,
      role,
      agentCode: agentCode || null,
      shippingCompanyId: shippingCompanyId || null,
      isEnabled: Number(isEnabled ?? 1),
      email: email || null,
      emailVerified: email ? (emailVerified ? 1 : 0) : 0,
      emailVerifiedAt: email && emailVerified ? (emailVerifiedAt || new Date().toISOString()) : null,
      password: finalPassword,
      mustChangePassword: finalMustChange,
      tokenVersion: Number(tokenVersion ?? 0)
    });
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  if (/UPDATE\s+app_users\s+SET/i.test(cleanSql)) {
    if (/^\s*UPDATE\s+app_users\s+SET\s+tokenVersion\s*=\s*COALESCE\(\s*tokenVersion\s*,\s*0\s*\)\s*\+\s*1\s+WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
      const id = values[0];
      const usr = jsonData.app_users.find((u: any) => u.id === id);
      if (usr) {
        usr.tokenVersion = (Number(usr.tokenVersion) || 0) + 1;
        saveJsonData(jsonData);
      }
    } else if (/^\s*UPDATE\s+app_users\s+SET\s+emailVerified\s*=\s*1\s*,\s*emailVerifiedAt\s*=\s*\?\s+WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
      const [verifiedAt, id] = values;
      const usr = jsonData.app_users.find((u: any) => u.id === id);
      if (usr) {
        usr.emailVerified = 1;
        usr.emailVerifiedAt = verifiedAt;
        saveJsonData(jsonData);
      }
    } else if (/^\s*UPDATE\s+app_users\s+SET\s+isEnabled\s*=/i.test(cleanSql)) {
      const isEnabledValue = /isEnabled\s*=\s*\?/i.test(cleanSql) ? values[0] : null;
      const id = /isEnabled\s*=\s*\?/i.test(cleanSql) ? (isEnabledValue !== null ? values[1] : values[0]) : values[0];
      const usr = jsonData.app_users.find((u: any) => u.id === id);
      if (usr) {
        if (isEnabledValue !== null) {
          usr.isEnabled = isEnabledValue ? 1 : 0;
        } else {
          usr.isEnabled = usr.isEnabled === 1 ? 0 : 1;
        }
        if (usr.isEnabled === 0) {
          usr.tokenVersion = (Number(usr.tokenVersion) || 0) + 1;
        }
        saveJsonData(jsonData);
      }
    } else if (/password\s*=\s*\?/i.test(cleanSql) && /WHERE\s+id\s*=\s*\?/i.test(cleanSql) && !/username\s*=\s*\?/i.test(cleanSql) && values.length <= 3) {
      const newPassword = values[0];
      const id = values[values.length - 1];
      const usr = jsonData.app_users.find((u: any) => u.id === id);
      if (usr) {
        usr.password = isBcryptHash(newPassword) ? newPassword : hashPasswordSync(newPassword);
        if (/mustChangePassword\s*=\s*0/i.test(cleanSql)) {
          usr.mustChangePassword = 0;
        } else if (/mustChangePassword\s*=\s*1/i.test(cleanSql)) {
          usr.mustChangePassword = 1;
        } else if (/mustChangePassword\s*=\s*\?/i.test(cleanSql) && values.length === 3) {
          usr.mustChangePassword = Number(values[1]);
        }
        if (/tokenVersion\s*=\s*COALESCE\(\s*tokenVersion\s*,\s*0\s*\)\s*\+\s*1/i.test(cleanSql)) {
          usr.tokenVersion = (Number(usr.tokenVersion) || 0) + 1;
        }
        saveJsonData(jsonData);
      }
    } else if (/password\s*=\s*\?/i.test(cleanSql) && /WHERE\s+phoneNumber\s*=\s*\?/i.test(cleanSql) && values.length <= 3) {
      const newPassword = values[0];
      const phoneNumber = values[values.length - 1];
      const usr = jsonData.app_users.find((u: any) => u.phoneNumber === phoneNumber);
      if (usr) {
        usr.password = isBcryptHash(newPassword) ? newPassword : hashPasswordSync(newPassword);
        if (/mustChangePassword\s*=\s*0/i.test(cleanSql)) {
          usr.mustChangePassword = 0;
        }
        if (/tokenVersion\s*=\s*COALESCE\(\s*tokenVersion\s*,\s*0\s*\)\s*\+\s*1/i.test(cleanSql)) {
          usr.tokenVersion = (Number(usr.tokenVersion) || 0) + 1;
        }
        saveJsonData(jsonData);
      }
    } else if (/phoneNumber\s+=\s+\?\s+WHERE/i.test(cleanSql)) {
      const [newPhoneNumber, idOrCode] = values;
      const usr = jsonData.app_users.find((u: any) => u.id === idOrCode || u.agentCode === idOrCode || u.shippingCompanyId === idOrCode);
      if (usr) {
        usr.phoneNumber = newPhoneNumber;
        saveJsonData(jsonData);
      }
    } else if (/WHERE\s+agentCode\s+=\s+\?/i.test(cleanSql)) {
      const targetAgentCode = values[values.length - 1];
      const usr = jsonData.app_users.find((u: any) => u.agentCode === targetAgentCode);
      if (usr) {
        usr.fullName = values[0] || usr.fullName;
        usr.phoneNumber = values[1] || usr.phoneNumber;
        saveJsonData(jsonData);
      }
    } else if (/WHERE\s+shippingCompanyId\s+=\s+\?/i.test(cleanSql)) {
      const targetScId = values[values.length - 1];
      const usr = jsonData.app_users.find((u: any) => u.shippingCompanyId === targetScId);
      if (usr) {
        usr.fullName = values[0] || usr.fullName;
        usr.phoneNumber = values[1] || usr.phoneNumber;
        saveJsonData(jsonData);
      }
    } else {
      const id = values[values.length - 1];
      const usr = jsonData.app_users.find((u: any) => u.id === id);
      if (usr) {
        let idx = 0;
        if (/username\s*=\s*\?/i.test(cleanSql)) usr.username = values[idx++];
        if (/fullName\s*=\s*\?/i.test(cleanSql)) usr.fullName = values[idx++];
        if (/phoneNumber\s*=\s*\?/i.test(cleanSql)) usr.phoneNumber = values[idx++];
        if (/role\s*=\s*\?/i.test(cleanSql)) usr.role = values[idx++];
        if (/agentCode\s*=\s*\?/i.test(cleanSql)) usr.agentCode = values[idx++] || null;
        if (/shippingCompanyId\s*=\s*\?/i.test(cleanSql)) usr.shippingCompanyId = values[idx++] || null;
        if (/isEnabled\s*=\s*\?/i.test(cleanSql)) usr.isEnabled = Number(values[idx++]);
        if (/email\s*=\s*\?/i.test(cleanSql)) usr.email = values[idx++] || null;
        if (/emailVerified\s*=\s*\?/i.test(cleanSql)) usr.emailVerified = Number(values[idx++]);
        if (/emailVerifiedAt\s*=\s*\?/i.test(cleanSql)) usr.emailVerifiedAt = values[idx++] || null;
        if (/password\s*=\s*\?/i.test(cleanSql)) {
          const rawPassword = values[idx++];
          usr.password = isBcryptHash(rawPassword) ? rawPassword : hashPasswordSync(rawPassword);
        }
        if (/mustChangePassword\s*=\s*\?/i.test(cleanSql)) {
          usr.mustChangePassword = Number(values[idx++]);
        } else if (/mustChangePassword\s*=\s*0/i.test(cleanSql)) {
          usr.mustChangePassword = 0;
        } else if (/mustChangePassword\s*=\s*1/i.test(cleanSql)) {
          usr.mustChangePassword = 1;
        }
        if (/tokenVersion\s*=\s*COALESCE\(\s*tokenVersion\s*,\s*0\s*\)\s*\+\s*1/i.test(cleanSql)) {
          usr.tokenVersion = (Number(usr.tokenVersion) || 0) + 1;
        }
        saveJsonData(jsonData);
      }
    }
    return [{ affectedRows: 1 }];
  }

  if (/DELETE\s+FROM\s+app_users/i.test(cleanSql)) {
    const id = values[0];
    jsonData.app_users = jsonData.app_users.filter((u: any) => u.id !== id);
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 1. SELECT * FROM products
  if (/SELECT\s+\*\s+FROM\s+products/i.test(cleanSql)) {
    return [jsonData.products.map((p: any) => ({ ...p, isEnabled: p.isEnabled === 1 || p.isEnabled === true ? 1 : 0 })), []];
  }

  // 2. SELECT * FROM agents
  if (/SELECT\s+.*?\s+FROM\s+agents/i.test(cleanSql)) {
    let list = (jsonData.agents || []).map((a: any) => ({ ...a, isEnabled: a.isEnabled === 1 || a.isEnabled === true ? 1 : 0 }));
    if (/WHERE\s+1\s*=\s*0/i.test(cleanSql)) {
      list = [];
    } else if (/WHERE\s+agentCode\s*=\s*\?/i.test(cleanSql)) {
      const targetAgentCode = values[0] ? String(values[0]).trim() : "";
      list = list.filter((a: any) => a.agentCode && String(a.agentCode).trim() === targetAgentCode);
    } else if (/WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
      const targetId = values[0] ? String(values[0]).trim() : "";
      list = list.filter((a: any) => a.id === targetId);
    }
    return [list, []];
  }

  // 3. SELECT * FROM shipping_companies
  if (/SELECT\s+.*?\s+FROM\s+shipping_companies/i.test(cleanSql)) {
    let list = (jsonData.shipping_companies || []).map((s: any) => ({ ...s, isEnabled: s.isEnabled === 1 || s.isEnabled === true ? 1 : 0 }));
    if (/WHERE\s+1\s*=\s*0/i.test(cleanSql)) {
      list = [];
    } else if (/WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
      const targetId = values[0] ? String(values[0]).trim() : "";
      list = list.filter((s: any) => s.id === targetId);
    } else if (/WHERE\s+isEnabled\s*=\s*1/i.test(cleanSql)) {
      list = list.filter((s: any) => s.isEnabled === 1);
    }
    return [list, []];
  }

  // 3b. SELECT * FROM permanent_drivers
  if (/SELECT\s+.*?\s+FROM\s+permanent_drivers/i.test(cleanSql)) {
    let list = (jsonData.permanent_drivers || []).map((d: any) => ({ ...d, isEnabled: d.isEnabled === 1 || d.isEnabled === true ? 1 : 0 }));
    if (/WHERE\s+1\s*=\s*0/i.test(cleanSql)) {
      list = [];
    } else if (/WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
      const targetId = values[0] ? String(values[0]).trim() : "";
      list = list.filter((d: any) => d.id === targetId);
    } else if (/WHERE\s+driverPhone\s*=\s*\?\s*OR\s*\(\s*driverName\s*=\s*\?\s*AND\s*licensePlate\s*=\s*\?\s*\)/i.test(cleanSql)) {
      const [phone, dName, plate] = values;
      list = list.filter((d: any) => d.driverPhone === phone || (d.driverName === dName && d.licensePlate === plate));
    }
    return [list, []];
  }

  // 4. SELECT * FROM orders (supports WHERE agentCode = ?, WHERE shippingCompanyId = ?, status IN (...), WHERE 1 = 0, WHERE id = ?)
  if (/SELECT\s+\*\s+FROM\s+orders/i.test(cleanSql)) {
    let list = [...jsonData.orders];
    const statusInMatch = cleanSql.match(/status\s+IN\s*\(([^)]+)\)/i);
    const allowedStatuses = statusInMatch
      ? statusInMatch[1].split(',').map((s) => s.trim().replace(/^['"]|['"]$/g, ''))
      : null;

    if (/WHERE\s+1\s*=\s*0/i.test(cleanSql)) {
      list = [];
    } else if (/WHERE\s+agentCode\s*=\s*\?/i.test(cleanSql)) {
      const targetAgentCode = values[0];
      list = list.filter((o: any) => o.agentCode === targetAgentCode);
      if (allowedStatuses) {
        list = list.filter((o: any) => allowedStatuses.includes(o.status));
      }
    } else if (/WHERE\s+shippingCompanyId\s*=\s*\?/i.test(cleanSql)) {
      const targetScId = values[0];
      list = list.filter((o: any) => o.shippingCompanyId === targetScId);
      if (allowedStatuses) {
        list = list.filter((o: any) => allowedStatuses.includes(o.status));
      }
    } else if (/WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
      const targetId = values[0];
      list = list.filter((o: any) => o.id === targetId);
    } else if (allowedStatuses) {
      list = list.filter((o: any) => allowedStatuses.includes(o.status));
    }

    list.sort((a, b) => {
      if (a.priorityIndex !== b.priorityIndex) {
        return (a.priorityIndex || 0) - (b.priorityIndex || 0);
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    return [list, []];
  }

  // 4b. SELECT ... FROM orders WHERE id = ?
  if (/SELECT\s+.*?\s+FROM\s+orders\s+WHERE\s+id\s*=\s*\?/i.test(cleanSql)) {
    const targetId = values[0];
    const ord = jsonData.orders.find((o: any) => o.id === targetId);
    return [ord ? [ord] : [], []];
  }

  // 5. SELECT * FROM order_history (supports WHERE orderId IN (?))
  if (/SELECT\s+\*\s+FROM\s+order_history/i.test(cleanSql)) {
    let list = [...jsonData.order_history];
    if (/WHERE\s+orderId\s+IN/i.test(cleanSql) && values[0]) {
      const allowedIds = new Set(Array.isArray(values[0]) ? values[0] : [values[0]]);
      list = list.filter((h: any) => allowedIds.has(h.orderId));
    }
    list.sort((a, b) => {
      return new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
    });
    return [list, []];
  }

  // 6. SELECT COUNT(*) as count FROM <table>
  const countMatch = cleanSql.match(/SELECT\s+COUNT\(\*\)\s+(?:as\s+count\s+)?FROM\s+([a-z0-9_]+)/i);
  if (countMatch) {
    const tableName = countMatch[1].toLowerCase();
    const tableData = (jsonData as any)[tableName] || [];
    return [[{ count: tableData.length }], []];
  }

  // 7. SELECT id FROM orders WHERE status = 'PENDING_APPROVAL'
  if (/SELECT\s+id\s+FROM\s+orders\s+WHERE\s+status\s+=\s+'PENDING_APPROVAL'/i.test(cleanSql)) {
    const matched = jsonData.orders.filter((o: any) => o.status === 'PENDING_APPROVAL').map((o: any) => ({ id: o.id }));
    return [matched, []];
  }

  // 8. SELECT id FROM orders WHERE status = 'APPROVED_BY_SALES'
  if (/SELECT\s+id\s+FROM\s+orders\s+WHERE\s+status\s+=\s+'APPROVED_BY_SALES'/i.test(cleanSql)) {
    const matched = jsonData.orders.filter((o: any) => o.status === 'APPROVED_BY_SALES').map((o: any) => ({ id: o.id }));
    return [matched, []];
  }

  // 9. INSERT INTO products
  if (/INSERT\s+INTO\s+products/i.test(cleanSql)) {
    const [id, name, category, pricePerUnit, unit, description, weight, dimensions, coverageInfo, primaryUnit, secondaryUnit, conversionRatio, defaultQuantity, imageUrl] = values;
    if (jsonData.products.some((p: any) => p.id === id)) {
      const err: any = new Error("Product duplicate error");
      err.code = "ER_DUP_ENTRY";
      err.errno = 1062;
      throw err;
    }
    jsonData.products.push({
      id,
      name,
      category,
      pricePerUnit: Number(pricePerUnit),
      unit,
      description: description || null,
      weight: weight || null,
      dimensions: dimensions || null,
      coverageInfo: coverageInfo || null,
      primaryUnit: primaryUnit || null,
      secondaryUnit: secondaryUnit || null,
      conversionRatio: conversionRatio ? Number(conversionRatio) : null,
      defaultQuantity: defaultQuantity ? Number(defaultQuantity) : 330,
      imageUrl: imageUrl || null,
      isEnabled: 1
    });
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 10. UPDATE products SET isEnabled = NOT isEnabled WHERE id = ?
  if (/UPDATE\s+products\s+SET\s+isEnabled\s+=\s+NOT\s+isEnabled\s+WHERE\s+id\s+=\s+\?/i.test(cleanSql)) {
    const id = values[0];
    const prod = jsonData.products.find((p: any) => p.id === id);
    if (prod) {
      prod.isEnabled = (prod.isEnabled === 1 || prod.isEnabled === true) ? 0 : 1;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  // 11. DELETE FROM products WHERE id = ?
  if (/DELETE\s+FROM\s+products\s+WHERE\s+id/i.test(cleanSql)) {
    const id = values[0];
    jsonData.products = jsonData.products.filter((p: any) => p.id !== id);
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 12. INSERT INTO agents
  if (/INSERT\s+INTO\s+agents/i.test(cleanSql)) {
    let id, fullName, alias, agentCode, phoneNumber, address, area, territories, isExportAgent, personType, companyName, registrationNumber, economicCode, nationalId, nationalCode;
    if (values.length >= 15) {
      [id, fullName, alias, agentCode, phoneNumber, address, area, territories, isExportAgent, personType, companyName, registrationNumber, economicCode, nationalId, nationalCode] = values;
    } else if (values.length >= 9) {
      [id, fullName, alias, agentCode, phoneNumber, address, area, territories, isExportAgent] = values;
    } else {
      [id, fullName, alias, agentCode, phoneNumber, address, area, territories] = values;
    }
    if (agentCode && jsonData.agents.some((a: any) => a.agentCode && a.agentCode.toUpperCase() === agentCode.toUpperCase())) {
      const err: any = new Error("Agent duplicate error");
      err.code = "ER_DUP_ENTRY";
      err.errno = 1062;
      throw err;
    }
    let territoriesParsed = null;
    if (territories) {
      try { territoriesParsed = typeof territories === 'string' ? JSON.parse(territories) : territories; } catch(e) { territoriesParsed = territories; }
    }
    jsonData.agents.push({
      id,
      fullName,
      alias,
      agentCode,
      phoneNumber,
      address: address || null,
      area: area || null,
      territories: territoriesParsed,
      isExportAgent: Number(isExportAgent) === 1 || isExportAgent === true,
      isEnabled: 1,
      personType: personType || 'REAL',
      companyName: companyName || null,
      registrationNumber: registrationNumber || null,
      economicCode: economicCode || null,
      nationalId: nationalId || null,
      nationalCode: nationalCode || null
    });
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 13. UPDATE agents SET isEnabled = NOT isEnabled WHERE id = ?
  if (/UPDATE\s+agents\s+SET\s+isEnabled\s+=\s+NOT\s+isEnabled\s+WHERE\s+id\s+=\s+\?/i.test(cleanSql)) {
    const id = values[0];
    const agent = jsonData.agents.find((a: any) => a.id === id);
    if (agent) {
      agent.isEnabled = (agent.isEnabled === 1 || agent.isEnabled === true) ? 0 : 1;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  // 14. DELETE FROM agents WHERE id = ?
  if (/DELETE\s+FROM\s+agents\s+WHERE\s+id/i.test(cleanSql)) {
    const id = values[0];
    jsonData.agents = jsonData.agents.filter((a: any) => a.id !== id);
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 15. INSERT INTO shipping_companies
  if (/INSERT\s+INTO\s+shipping_companies/i.test(cleanSql)) {
    let id, name, code, phoneNumber, managerName, nationalId, economicCode;
    if (values.length >= 7) {
      [id, name, code, phoneNumber, managerName, nationalId, economicCode] = values;
    } else {
      [id, name, code, phoneNumber, managerName] = values;
    }
    if (code && jsonData.shipping_companies.some((sc: any) => sc.code && sc.code.toUpperCase() === code.toUpperCase())) {
      const err: any = new Error("Company duplicate error");
      err.code = "ER_DUP_ENTRY";
      err.errno = 1062;
      throw err;
    }
    jsonData.shipping_companies.push({
      id,
      name,
      code,
      phoneNumber,
      managerName: managerName || null,
      isEnabled: 1,
      nationalId: nationalId || null,
      economicCode: economicCode || null
    });
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 16. UPDATE shipping_companies
  if (/UPDATE\s+shipping_companies\s+SET/i.test(cleanSql) && !/isEnabled\s+=\s+NOT/i.test(cleanSql)) {
    if (/phoneNumber\s+=\s+\?,\s+address\s+=\s+\?/i.test(cleanSql)) {
      const [phoneNumber, address, scId] = values;
      const sc = jsonData.shipping_companies.find((s: any) => s.id === scId || s.code === scId);
      if (sc) {
        sc.phoneNumber = phoneNumber;
        sc.address = address;
        saveJsonData(jsonData);
      }
    } else if (values.length >= 8) {
      const [name, code, phoneNumber, managerName, address, isEnabled, nationalId, economicCode, id] = values;
      const sc = jsonData.shipping_companies.find((s: any) => s.id === id);
      if (sc) {
        sc.name = name;
        sc.code = code;
        sc.phoneNumber = phoneNumber;
        sc.managerName = managerName;
        sc.address = address;
        sc.isEnabled = Number(isEnabled) === 1 || isEnabled === true;
        if (nationalId !== undefined) sc.nationalId = nationalId;
        if (economicCode !== undefined) sc.economicCode = economicCode;
        saveJsonData(jsonData);
      }
    } else if (values.length >= 7) {
      const [name, code, phoneNumber, managerName, address, isEnabled, id] = values;
      const sc = jsonData.shipping_companies.find((s: any) => s.id === id);
      if (sc) {
        sc.name = name;
        sc.code = code;
        sc.phoneNumber = phoneNumber;
        sc.managerName = managerName;
        sc.address = address;
        sc.isEnabled = Number(isEnabled) === 1 || isEnabled === true;
        saveJsonData(jsonData);
      }
    } else {
      const id = values[values.length - 1];
      const sc = jsonData.shipping_companies.find((s: any) => s.id === id);
      if (sc) {
        if (values.length >= 3) sc.phoneNumber = values[2] || sc.phoneNumber;
        saveJsonData(jsonData);
      }
    }
    return [{ affectedRows: 1 }];
  }

  if (/UPDATE\s+shipping_companies\s+SET\s+isEnabled\s+=\s+NOT\s+isEnabled\s+WHERE\s+id\s+=\s+\?/i.test(cleanSql)) {
    const id = values[0];
    const company = jsonData.shipping_companies.find((s: any) => s.id === id);
    if (company) {
      company.isEnabled = (company.isEnabled === 1 || company.isEnabled === true) ? 0 : 1;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  // 17. DELETE FROM shipping_companies WHERE id = ?
  if (/DELETE\s+FROM\s+shipping_companies\s+WHERE\s+id/i.test(cleanSql)) {
    const id = values[0];
    jsonData.shipping_companies = jsonData.shipping_companies.filter((s: any) => s.id !== id);
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 17b. PERMANENT DRIVERS CRUD IN FALLBACK SQL
  if (/INSERT\s+INTO\s+permanent_drivers/i.test(cleanSql)) {
    if (!jsonData.permanent_drivers) jsonData.permanent_drivers = [];
    let id: any, driverName: any, driverPhone: any, licensePlate: any, vehicleType: any, shippingAgency: any, shippingCompanyId: any = null, nationalCode: any = null, smartCardNumber: any = null, isEnabled: any = 1;
    const colsMatch = cleanSql.match(/INSERT\s+INTO\s+permanent_drivers\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)/i);
    if (colsMatch) {
      const colNames = colsMatch[1].split(",").map((c) => c.trim().replace(/[`"']/g, ""));
      const valTokens = colsMatch[2].split(",").map((t) => t.trim());
      let vIdx = 0;
      const mapped: Record<string, any> = {};
      colNames.forEach((col, i) => {
        const tok = valTokens[i];
        if (tok === "?") {
          mapped[col] = values[vIdx++];
        } else if (tok === "NULL" || tok === "null") {
          mapped[col] = null;
        } else if (tok === "0" || tok === "1") {
          mapped[col] = Number(tok);
        } else if (tok) {
          mapped[col] = tok.replace(/^['"]|['"]$/g, "");
        }
      });
      id = mapped.id;
      driverName = mapped.driverName;
      driverPhone = mapped.driverPhone;
      licensePlate = mapped.licensePlate;
      vehicleType = mapped.vehicleType;
      shippingAgency = mapped.shippingAgency ?? null;
      shippingCompanyId = mapped.shippingCompanyId ?? null;
      nationalCode = mapped.nationalCode ?? null;
      smartCardNumber = mapped.smartCardNumber ?? null;
      isEnabled = mapped.isEnabled !== undefined ? mapped.isEnabled : 1;
    } else if (/shippingCompanyId/i.test(cleanSql) && values.length >= 9) {
      [id, driverName, driverPhone, licensePlate, vehicleType, shippingAgency, shippingCompanyId, nationalCode, smartCardNumber] = values;
    } else {
      [id, driverName, driverPhone, licensePlate, vehicleType, shippingAgency, nationalCode, smartCardNumber] = values;
    }
    jsonData.permanent_drivers.push({
      id,
      driverName,
      driverPhone,
      licensePlate,
      vehicleType,
      shippingAgency: shippingAgency || null,
      shippingCompanyId: shippingCompanyId || null,
      nationalCode: nationalCode || null,
      smartCardNumber: smartCardNumber || null,
      isEnabled: Number(isEnabled ?? 1)
    });
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  if (/UPDATE\s+permanent_drivers\s+SET\s+isEnabled\s+=\s+NOT\s+isEnabled\s+WHERE\s+id\s+=\s+\?/i.test(cleanSql)) {
    const id = values[0];
    const drv = (jsonData.permanent_drivers || []).find((d: any) => d.id === id);
    if (drv) {
      drv.isEnabled = (drv.isEnabled === 1 || drv.isEnabled === true) ? 0 : 1;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  if (/UPDATE\s+permanent_drivers\s+SET/i.test(cleanSql) && !/isEnabled\s+=\s+NOT/i.test(cleanSql)) {
    let driverName: any, driverPhone: any, licensePlate: any, vehicleType: any, shippingAgency: any, shippingCompanyId: any, nationalCode: any, smartCardNumber: any, isEnabled: any, id: any;
    if (/shippingCompanyId/i.test(cleanSql) && values.length >= 10) {
      [driverName, driverPhone, licensePlate, vehicleType, shippingAgency, shippingCompanyId, nationalCode, smartCardNumber, isEnabled, id] = values;
    } else {
      [driverName, driverPhone, licensePlate, vehicleType, shippingAgency, nationalCode, smartCardNumber, isEnabled, id] = values;
    }
    const drv = (jsonData.permanent_drivers || []).find((d: any) => d.id === id);
    if (drv) {
      drv.driverName = driverName;
      drv.driverPhone = driverPhone;
      drv.licensePlate = licensePlate;
      drv.vehicleType = vehicleType;
      drv.shippingAgency = shippingAgency || null;
      if (shippingCompanyId !== undefined) drv.shippingCompanyId = shippingCompanyId || null;
      drv.nationalCode = nationalCode || null;
      drv.smartCardNumber = smartCardNumber || null;
      drv.isEnabled = Number(isEnabled) === 1 || isEnabled === true;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  if (/DELETE\s+FROM\s+permanent_drivers\s+WHERE\s+id/i.test(cleanSql)) {
    const id = values[0];
    jsonData.permanent_drivers = (jsonData.permanent_drivers || []).filter((d: any) => d.id !== id);
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 18. INSERT INTO orders
  if (/INSERT\s+INTO\s+orders/i.test(cleanSql)) {
    const colsMatch = cleanSql.match(/INSERT\s+INTO\s+orders\s*\((.*?)\)\s*VALUES/i);
    const newOrder: any = {
      id: values[0] || `ord-${Date.now()}`,
      orderNumber: values[1] || '',
      customerName: values[2] || '',
      agentCode: values[3] || '',
      productId: values[4] || '',
      productName: values[5] || '',
      quantity: Number(values[6]) || 0,
      unit: values[7] || 'مترمربع',
      destinationCity: values[8] || '',
      exactAddress: values[9] || null,
      phoneNumber: values[10] || '',
      buyerName: null,
      notes: null,
      createdAt: new Date().toISOString(),
      status: 'PENDING_APPROVAL',
      priorityIndex: 0,
      sentToFactoryAt: null,
      rejectionReason: null,
      vehicleType: null,
      driverName: null,
      driverPhone: null,
      licensePlate: null,
      shippingAgency: null,
      estimatedArrival: null,
      itemsJson: null,
      paymentTrackingCode: null,
      paymentReceiptUrl: null,
      paymentReceiptName: null,
      billOfLadingNumber: null,
      shippingCompanyId: null,
      isExportOrder: 0,
      destinationCountry: null,
      deliveryLocationUrl: null,
      hasPendingEdit: 0,
      pendingEditData: null
    };

    if (colsMatch) {
      const colNames = colsMatch[1].split(',').map(c => c.trim().replace(/[`"']/g, ''));
      let valIndex = 0;
      colNames.forEach((col) => {
        if (col === 'priorityIndex' && !cleanSql.includes('?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,')) {
          // Check if priorityIndex was hardcoded like ", 0," in VALUES
          // If so, it might not consume a placeholder
        }
        // Match against placeholder values
        if (valIndex < values.length) {
          const val = values[valIndex];
          if (col === 'quantity' || col === 'priorityIndex') {
            newOrder[col] = val !== null && val !== undefined ? Number(val) : 0;
          } else if (col === 'isExportOrder' || col === 'hasPendingEdit') {
            newOrder[col] = val ? 1 : 0;
          } else {
            newOrder[col] = val;
          }
          valIndex++;
        }
      });
    } else {
      // Positional fallback
      newOrder.buyerName = values[11] || null;
      newOrder.notes = values[12] || null;
      newOrder.createdAt = values[13] || new Date().toISOString();
      newOrder.status = values[14] || 'PENDING_APPROVAL';
      newOrder.itemsJson = values[15] || null;
      newOrder.paymentTrackingCode = values[16] || null;
      newOrder.paymentReceiptUrl = values[17] || null;
      newOrder.paymentReceiptName = values[18] || null;
      newOrder.isExportOrder = values[19] ? 1 : 0;
      newOrder.destinationCountry = values[20] || null;
      newOrder.deliveryLocationUrl = values[21] || null;
    }

    // Ensure array exists
    if (!jsonData.orders) jsonData.orders = [];
    jsonData.orders.push(newOrder);
    saveJsonData(jsonData);
    return [{ affectedRows: 1, insertId: newOrder.id }];
  }

  // 19. INSERT INTO order_history
  if (/INSERT\s+INTO\s+order_history/i.test(cleanSql)) {
    const [orderId, status, updatedAt, comment] = values;
    if (!jsonData.order_history) jsonData.order_history = [];
    jsonData.order_history.push({
      id: jsonData.order_history.length + 1,
      orderId,
      status,
      updatedAt,
      comment: comment || null
    });
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 20. UPDATE orders updates
  if (/UPDATE\s+orders\s+SET/i.test(cleanSql)) {
    const setMatch = cleanSql.match(/UPDATE\s+orders\s+SET\s+(.*?)\s+WHERE\s+id\s*=\s*(\?|'[^']+'|"[^"]+");?/i);
    if (setMatch) {
      const setClause = setMatch[1];
      const idMatch = setMatch[2];
      const id = idMatch === '?' ? values[values.length - 1] : idMatch.replace(/['"]/g, '');
      const ord = jsonData.orders.find((o: any) => o.id === id);
      if (ord) {
        const assignments = setClause.split(',').map(s => s.trim());
        let valIdx = 0;
        assignments.forEach(assign => {
          const parts = assign.split('=').map(s => s.trim());
          const colName = parts[0]?.replace(/[`"']/g, '');
          const valExpr = parts[1];
          if (colName) {
            let finalVal: any = undefined;
            if (valExpr === '?' || (valExpr && valExpr.includes('?'))) {
              const currentVal = values[valIdx++];
              if (valExpr.toUpperCase().includes('COALESCE')) {
                finalVal = currentVal !== null && currentVal !== undefined && currentVal !== '' ? currentVal : ord[colName];
              } else {
                finalVal = currentVal;
              }
            } else if (valExpr === 'NULL' || valExpr === 'null') {
              finalVal = null;
            } else if (valExpr === '0') {
              finalVal = 0;
            } else if (valExpr === '1') {
              finalVal = 1;
            }

            if (finalVal !== undefined) {
              if (colName === 'quantity' || colName === 'priorityIndex') {
                ord[colName] = finalVal !== null ? Number(finalVal) : 0;
              } else if (colName === 'hasPendingEdit' || colName === 'isExportOrder') {
                ord[colName] = finalVal ? 1 : 0;
              } else {
                ord[colName] = finalVal;
              }
            }
          }
        });
        saveJsonData(jsonData);
      }
      return [{ affectedRows: 1 }];
    }
    return [{ affectedRows: 1 }];
  }

  // 20b. UPDATE products details in fallback SQL
  if (/UPDATE\s+products\s+SET/i.test(cleanSql) && !/isEnabled\s+=\s+NOT/i.test(cleanSql)) {
    const [name, category, pricePerUnit, unit, description, weight, dimensions, coverageInfo, primaryUnit, secondaryUnit, conversionRatio, defaultQuantity, isEnabled, imageUrl, id] = values;
    const prod = jsonData.products.find((p: any) => p.id === id);
    if (prod) {
      prod.name = name;
      prod.category = category;
      prod.pricePerUnit = Number(pricePerUnit);
      prod.unit = unit;
      prod.description = description || null;
      prod.weight = weight || null;
      prod.dimensions = dimensions || null;
      prod.coverageInfo = coverageInfo || null;
      prod.primaryUnit = primaryUnit || null;
      prod.secondaryUnit = secondaryUnit || null;
      prod.conversionRatio = conversionRatio ? Number(conversionRatio) : null;
      prod.defaultQuantity = defaultQuantity ? Number(defaultQuantity) : 330;
      prod.isEnabled = Number(isEnabled) === 1 || isEnabled === true;
      prod.imageUrl = imageUrl || null;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  // 20c. UPDATE agents details in fallback SQL
  if (/UPDATE\s+agents\s+SET/i.test(cleanSql) && !/isEnabled\s+=\s+NOT/i.test(cleanSql)) {
    if (/phoneNumber\s+=\s+\?,\s+address\s+=\s+\?\s+WHERE/i.test(cleanSql)) {
      const [phoneNumber, address, agentCodeOrId] = values;
      const ag = jsonData.agents.find((a: any) => a.agentCode === agentCodeOrId || a.id === agentCodeOrId);
      if (ag) {
        ag.phoneNumber = phoneNumber;
        ag.address = address;
        saveJsonData(jsonData);
      }
      return [{ affectedRows: 1 }];
    }
    let fullName, alias, agentCode, phoneNumber, address, area, territories, isExportAgent, isEnabled, personType, companyName, registrationNumber, economicCode, nationalId, nationalCode, id;
    if (values.length >= 16) {
      [fullName, alias, agentCode, phoneNumber, address, area, territories, isExportAgent, isEnabled, personType, companyName, registrationNumber, economicCode, nationalId, nationalCode, id] = values;
    } else if (values.length >= 10) {
      [fullName, alias, agentCode, phoneNumber, address, area, territories, isExportAgent, isEnabled, id] = values;
    } else if (values.length >= 9) {
      [fullName, alias, agentCode, phoneNumber, address, area, territories, isEnabled, id] = values;
    } else {
      [fullName, alias, agentCode, phoneNumber, address, area, isEnabled, id] = values;
    }
    const ag = jsonData.agents.find((a: any) => a.id === id);
    if (ag) {
      ag.fullName = fullName;
      ag.alias = alias;
      ag.agentCode = agentCode;
      ag.phoneNumber = phoneNumber;
      ag.address = address || null;
      ag.area = area || null;
      if (territories !== undefined) {
        try { ag.territories = typeof territories === 'string' ? JSON.parse(territories) : territories; } catch(e) { ag.territories = territories; }
      }
      if (isExportAgent !== undefined) {
        ag.isExportAgent = Number(isExportAgent) === 1 || isExportAgent === true;
      }
      ag.isEnabled = Number(isEnabled) === 1 || isEnabled === true;
      if (personType !== undefined) ag.personType = personType;
      if (companyName !== undefined) ag.companyName = companyName;
      if (registrationNumber !== undefined) ag.registrationNumber = registrationNumber;
      if (economicCode !== undefined) ag.economicCode = economicCode;
      if (nationalId !== undefined) ag.nationalId = nationalId;
      if (nationalCode !== undefined) ag.nationalCode = nationalCode;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  // 20d. UPDATE order paymentTrackingCode or cancellation in fallback SQL
  if (/UPDATE\s+orders\s+SET\s+paymentTrackingCode/i.test(cleanSql)) {
    const [paymentTrackingCode, id] = values;
    const ord = jsonData.orders.find((o: any) => o.id === id);
    if (ord) {
      ord.paymentTrackingCode = paymentTrackingCode;
      saveJsonData(jsonData);
    }
    return [{ affectedRows: 1 }];
  }

  // 21. TRUNCATE/CLEAN/DELETE
  if (/DELETE\s+FROM/i.test(cleanSql)) {
    if (cleanSql.includes("order_history")) jsonData.order_history = [];
    if (cleanSql.includes("orders")) jsonData.orders = [];
    if (cleanSql.includes("user_activity_logs")) {
      jsonData.user_activity_logs = [];
      inMemoryActivityLogs.length = 0;
    }
    if (cleanSql.includes("products")) jsonData.products = [];
    if (cleanSql.includes("agents")) jsonData.agents = [];
    if (cleanSql.includes("shipping_companies")) jsonData.shipping_companies = [];
    saveJsonData(jsonData);
    return [{ affectedRows: 1 }];
  }

  // 22. user_activity_logs handling in mock provider
  if (/INSERT\s+INTO\s+user_activity_logs/i.test(cleanSql)) {
    return [{ affectedRows: 1 }];
  }
  if (/SELECT\s+.*FROM\s+user_activity_logs/i.test(cleanSql)) {
    return [inMemoryActivityLogs.slice(0, 100), []];
  }

  return [[], []];
}

class MockPool {
  constructor() {
    if (isProductionEnvironment()) {
      throw new DatabaseMaintenanceError("MockPool cannot be initialized in production. Database is in maintenance mode.");
    }
  }
  async getConnection() {
    if (isProductionEnvironment()) {
      throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
    }
    return new MockConnection();
  }
  async query(sql: string, values?: any[]) {
    if (isProductionEnvironment()) {
      throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
    }
    return executeQuery(sql, values);
  }
}

class MockConnection {
  async beginTransaction() {}
  async commit() {}
  async rollback() {}
  async release() {}
  async query(sql: string, values?: any[]) {
    if (isProductionEnvironment()) {
      throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
    }
    return executeQuery(sql, values);
  }
}

function wrapPoolWithHealthTracking(rawPool: mysql.Pool): mysql.Pool {
  const origQuery = rawPool.query.bind(rawPool);
  const origExecute = rawPool.execute ? rawPool.execute.bind(rawPool) : origQuery;
  const origGetConnection = rawPool.getConnection.bind(rawPool);

  rawPool.query = async function(...args: any[]) {
    const isProbe = typeof args[0] === "string" && args[0].trim().toUpperCase() === "SELECT 1";
    if (!isProbe && isProductionEnvironment() && (!isDbHealthy && dbMaintenanceError)) {
      throw dbMaintenanceError;
    }
    try {
      const result = await (origQuery as any)(...args);
      if (!isDbHealthy) {
        markDatabaseHealthy();
      }
      return result;
    } catch (err: any) {
      if (isConnectionError(err)) {
        markDatabaseUnhealthy(err);
        writeServerErrorLog("Database Query Failure", err);
        throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
      }
      throw err;
    }
  } as any;

  rawPool.execute = async function(...args: any[]) {
    if (isProductionEnvironment() && (!isDbHealthy && dbMaintenanceError)) {
      throw dbMaintenanceError;
    }
    try {
      const result = await (origExecute as any)(...args);
      if (!isDbHealthy) {
        markDatabaseHealthy();
      }
      return result;
    } catch (err: any) {
      if (isConnectionError(err)) {
        markDatabaseUnhealthy(err);
        writeServerErrorLog("Database Execute Failure", err);
        throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
      }
      throw err;
    }
  } as any;

  rawPool.getConnection = async function() {
    if (isProductionEnvironment() && (!isDbHealthy && dbMaintenanceError)) {
      throw dbMaintenanceError;
    }
    try {
      const conn = await origGetConnection();
      if (!isDbHealthy) {
        markDatabaseHealthy();
      }
      return conn;
    } catch (err: any) {
      if (isConnectionError(err)) {
        markDatabaseUnhealthy(err);
        writeServerErrorLog("Database Connection Failure", err);
        throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
      }
      throw err;
    }
  };

  return rawPool;
}

/**
 * Initializes the MariaDB connection pool if not already active.
 */
export function ensurePoolInitialized(): mysql.Pool {
  if (!pool) {
    const host = process.env.DB_HOST || "localhost";
    const port = Number(process.env.DB_PORT) || 3306;
    const user = process.env.DB_USER || "root";
    const password = process.env.DB_PASSWORD || "";
    let database = process.env.DB_NAME || "salesdashboard";
    if (database === "sales_dashboard") {
      console.log("ℹ️ [Database] Overriding legacy database name 'sales_dashboard' with 'salesdashboard'.");
      database = "salesdashboard";
    }

    console.log(`[Database] Initializing MariaDB Connection Pool on ${host}:${port} (${database})...`);
    
    const rawPool = mysql.createPool({
      host,
      port,
      user,
      password,
      database,
      waitForConnections: true,
      connectionLimit: 15,
      queueLimit: 100, // Bounded queue to avoid memory exhaustion during outages
      enableKeepAlive: true,
      keepAliveInitialDelay: 10000,
      connectTimeout: 5000, // Bounded 5s connect timeout
    });

    (rawPool as any).on("error", (err: any) => {
      console.warn("⚠️ [MariaDB Pool Warning]:", err?.message || err);
      markDatabaseUnhealthy(err);
      writeServerErrorLog("MariaDB Pool Warning", err);
    });

    pool = wrapPoolWithHealthTracking(rawPool);
  }
  return pool;
}

/**
 * Returns the MariaDB (MySQL-compatible) connection pool.
 * Initializes the pool lazily on the first request with bounded timeouts and queue limits.
 */
export function getDbPool(): mysql.Pool {
  // Requirement 1 & 4: In production, never return mock/JSON pool; throw maintenance error if DB is down
  if (isProductionEnvironment()) {
    if (isFallbackMode) {
      throw new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly.");
    }
    if (!isDbHealthy) {
      throw (dbMaintenanceError || new DatabaseMaintenanceError("Database service is temporarily unavailable for maintenance. Please try again shortly."));
    }
  }

  if (pool) {
    return pool;
  }

  // In development, allow local mock pool
  if (isFallbackMode && mockPoolInstance) {
    return mockPoolInstance as any;
  }

  return ensurePoolInitialized();
}

/**
 * Safe Redis Client wrapper that catches and silences connection/timeout errors.
 */
class SafeRedisWrapper {
  private instance: Redis;

  constructor(instance: Redis) {
    this.instance = instance;
  }

  async ping(): Promise<string> {
    try {
      return await this.instance.ping();
    } catch (err: any) {
      console.warn("⚠️ [Redis Safe Wrapper] Error in PING:", err.message);
      return "PONG";
    }
  }

  async get(key: string): Promise<string | null> {
    try {
      return await this.instance.get(key);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in GET ${key}:`, err.message);
      return null;
    }
  }

  async set(key: string, value: string, mode?: string, duration?: number): Promise<string | null> {
    try {
      if (mode && duration !== undefined) {
        return await this.instance.set(key, value, mode as any, duration);
      }
      return await this.instance.set(key, value);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in SET ${key}:`, err.message);
      return null;
    }
  }

  async del(key: string): Promise<number> {
    try {
      return await this.instance.del(key);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in DEL ${key}:`, err.message);
      return 0;
    }
  }

  async incr(key: string): Promise<number> {
    try {
      return await this.instance.incr(key);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in INCR ${key}:`, err.message);
      return 0;
    }
  }

  async ttl(key: string): Promise<number> {
    try {
      return await this.instance.ttl(key);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in TTL ${key}:`, err.message);
      return -2;
    }
  }

  async expire(key: string, seconds: number): Promise<number> {
    try {
      return await this.instance.expire(key, seconds);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in EXPIRE ${key}:`, err.message);
      return 0;
    }
  }

  async keys(pattern: string): Promise<string[]> {
    try {
      return await this.instance.keys(pattern);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in KEYS ${pattern}:`, err.message);
      return [];
    }
  }

  async scan(cursor: string, ...args: (string | number)[]): Promise<[string, string[]]> {
    try {
      return await (this.instance as any).scan(cursor, ...args);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in SCAN ${cursor}:`, err.message);
      return ["0", []];
    }
  }

  async zadd(key: string, ...args: (string | number)[]): Promise<number> {
    try {
      return await (this.instance as any).zadd(key, ...args);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in ZADD ${key}:`, err.message);
      return 0;
    }
  }

  async zcard(key: string): Promise<number> {
    try {
      return await (this.instance as any).zcard(key);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in ZCARD ${key}:`, err.message);
      return 0;
    }
  }

  async zremrangebyscore(key: string, min: string | number, max: string | number): Promise<number> {
    try {
      return await (this.instance as any).zremrangebyscore(key, min, max);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in ZREMRANGEBYSCORE ${key}:`, err.message);
      return 0;
    }
  }

  async zrange(key: string, start: number, stop: number, ...args: string[]): Promise<string[]> {
    try {
      return await (this.instance as any).zrange(key, start, stop, ...args);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in ZRANGE ${key}:`, err.message);
      return [];
    }
  }

  async eval(script: string, numkeys: number, ...args: (string | number)[]): Promise<any> {
    try {
      return await (this.instance as any).eval(script, numkeys, ...args);
    } catch (err: any) {
      console.warn(`⚠️ [Redis Safe Wrapper] Error in EVAL:`, err.message);
      return null;
    }
  }
}

let safeRedisWrapperInstance: any = null;
let hasLoggedRedisDisabled = false;

export function setRedisClientForTesting(client: any): void {
  safeRedisWrapperInstance = client;
}

export function resetRedisStateForTesting(): void {
  safeRedisWrapperInstance = null;
  hasLoggedRedisDisabled = false;
}

/**
 * Returns the Redis client instance wrapped in SafeRedisWrapper.
 * Initializes the connection lazily.
 */
export function getRedisClient(): any {
  if (safeRedisWrapperInstance) {
    return safeRedisWrapperInstance;
  }
  if (!redis) {
    const host = process.env.REDIS_HOST;
    const port = Number(process.env.REDIS_PORT) || 6379;
    const password = process.env.REDIS_PASSWORD || undefined;

    if (!host) {
      if (!hasLoggedRedisDisabled) {
        hasLoggedRedisDisabled = true;
        console.info("ℹ️ [Redis] REDIS_HOST is not defined in environment secrets. Running in disk-fallback cache.");
      }
      return null;
    }

    try {
      console.log(`[Redis] Initializing Redis Client on ${host}:${port}...`);
      redis = new Redis({
        host,
        port,
        password,
        lazyConnect: true,
        maxRetriesPerRequest: 3,
        connectTimeout: 1000,
        enableOfflineQueue: false,
        retryStrategy(times) {
          if (times > 3) {
            console.warn("⚠️ [Redis] Max connect retries reached. Stopping reconnection attempts.");
            return null;
          }
          return Math.min(times * 100, 500);
        }
      });

      redis.on("connect", () => {
        console.log("⚡ [Redis] Connected successfully to Redis server!");
      });

      redis.on("error", (err) => {
        console.error("❌ [Redis] Connection Error:", err.message);
      });
    } catch (error) {
      console.error("❌ [Redis] Failed to initialize client instance:", error);
      return null;
    }
  }
  if (redis) {
    safeRedisWrapperInstance = new SafeRedisWrapper(redis);
    return safeRedisWrapperInstance;
  }
  return null;
}

/**
 * Ensures a column exists in a specific table for MariaDB/MySQL.
 */
async function ensureColumnExists(db: mysql.Pool, tableName: string, columnName: string, columnDefinition: string) {
  try {
    const [columns] = await db.query(`SHOW COLUMNS FROM ${tableName} LIKE ?`, [columnName]);
    if ((columns as any[]).length === 0) {
      console.log(`🔧 [Migration] Column '${columnName}' is missing in table '${tableName}'. Adding it...`);
      await db.query(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${columnDefinition}`);
      console.log(`✅ [Migration] Column '${columnName}' successfully added to table '${tableName}'.`);
    }
  } catch (err: any) {
    console.error(`⚠️ [Migration Error] Could not ensure column '${columnName}' in '${tableName}':`, err.message);
  }
}

async function ensureIndexExists(db: mysql.Pool, tableName: string, indexName: string, columnsSql: string) {
  try {
    const [indexes] = await db.query(`SHOW INDEX FROM ${tableName} WHERE Key_name = ?`, [indexName]);
    if ((indexes as any[]).length === 0) {
      console.log(`⚡ [Index Migration] Creating index '${indexName}' on table '${tableName}'...`);
      await db.query(`CREATE INDEX ${indexName} ON ${tableName} (${columnsSql})`);
      console.log(`✅ [Index Migration] Index '${indexName}' added.`);
    }
  } catch (err: any) {
    // Ignore index errors on mock/unsupported environments
  }
}

/**
 * Utility to test database readiness and create tables if they do not exist.
 * This is perfect for initial bootstrapping on Ubuntu.
 */
export async function bootstrapDatabase() {
  let connectivityVerified = false;
  try {
    const db = pool || ensurePoolInitialized();
    
    // Quick test query to verify MariaDB is up and reachable
    await db.query("SELECT 1");
    connectivityVerified = true;

    console.log("🔄 [Bootstrap] Checking MariaDB tables...");

    // 1. Create Products Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS products (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        category VARCHAR(100) NOT NULL,
        pricePerUnit DECIMAL(15, 2) NOT NULL,
        unit VARCHAR(50) NOT NULL,
        description LONGTEXT,
        weight VARCHAR(50),
        dimensions VARCHAR(50),
        coverageInfo VARCHAR(150),
        isEnabled TINYINT(1) DEFAULT 1,
        imageUrl LONGTEXT
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 2. Create Agents Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS agents (
        id VARCHAR(50) PRIMARY KEY,
        fullName VARCHAR(150) NOT NULL,
        alias VARCHAR(150) NOT NULL,
        agentCode VARCHAR(50) NOT NULL UNIQUE,
        phoneNumber VARCHAR(20) NOT NULL,
        address TEXT,
        area LONGTEXT,
        territories LONGTEXT,
        isExportAgent TINYINT(1) DEFAULT 0,
        isEnabled TINYINT(1) DEFAULT 1,
        personType VARCHAR(20) DEFAULT 'REAL',
        companyName VARCHAR(150),
        registrationNumber VARCHAR(50),
        economicCode VARCHAR(50),
        nationalId VARCHAR(50),
        nationalCode VARCHAR(50)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 3. Create Shipping Companies Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS shipping_companies (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        code VARCHAR(50) NOT NULL UNIQUE,
        phoneNumber VARCHAR(20) NOT NULL,
        managerName VARCHAR(150),
        address TEXT,
        isEnabled TINYINT(1) DEFAULT 1,
        nationalId VARCHAR(50),
        economicCode VARCHAR(50)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 3b. Create Permanent Drivers Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS permanent_drivers (
        id VARCHAR(50) PRIMARY KEY,
        driverName VARCHAR(150) NOT NULL,
        driverPhone VARCHAR(20) NOT NULL,
        licensePlate VARCHAR(50) NOT NULL,
        vehicleType VARCHAR(100) NOT NULL,
        shippingAgency VARCHAR(150) NULL,
        shippingCompanyId VARCHAR(50) NULL,
        nationalCode VARCHAR(20) NULL,
        smartCardNumber VARCHAR(50) NULL,
        isEnabled TINYINT(1) DEFAULT 1
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 4. Create Orders Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS orders (
        id VARCHAR(50) PRIMARY KEY,
        orderNumber VARCHAR(50) NOT NULL UNIQUE,
        customerName VARCHAR(150) NOT NULL,
        agentCode VARCHAR(50) NOT NULL,
        productId VARCHAR(50) NOT NULL,
        productName VARCHAR(150) NOT NULL,
        quantity INT NOT NULL,
        unit VARCHAR(50) NOT NULL,
        destinationCity VARCHAR(100) NOT NULL,
        exactAddress TEXT,
        phoneNumber VARCHAR(20) NOT NULL,
        buyerName VARCHAR(255) NULL,
        notes TEXT,
        createdAt VARCHAR(50) NOT NULL,
        sentToFactoryAt VARCHAR(50) NULL,
        status VARCHAR(50) NOT NULL,
        priorityIndex INT DEFAULT 0,
        rejectionReason TEXT,
        vehicleType VARCHAR(100) NULL,
        driverName VARCHAR(100) NULL,
        driverPhone VARCHAR(20) NULL,
        licensePlate VARCHAR(50) NULL,
        shippingAgency VARCHAR(150) NULL,
        estimatedArrival VARCHAR(100) NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 5. Create Order History Table for audit trail
    await db.query(`
      CREATE TABLE IF NOT EXISTS order_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        orderId VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        updatedAt VARCHAR(50) NOT NULL,
        comment TEXT,
        FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 6. Create App Users Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS app_users (
        id VARCHAR(50) PRIMARY KEY,
        username VARCHAR(100) NOT NULL UNIQUE,
        fullName VARCHAR(150) NOT NULL,
        phoneNumber VARCHAR(20) NOT NULL UNIQUE,
        role VARCHAR(50) NOT NULL,
        agentCode VARCHAR(50) NULL,
        shippingCompanyId VARCHAR(100) NULL,
        isEnabled TINYINT(1) DEFAULT 1,
        email VARCHAR(150) NULL,
        emailVerified TINYINT(1) NOT NULL DEFAULT 0,
        emailVerifiedAt VARCHAR(50) NULL,
        tokenVersion INT NOT NULL DEFAULT 0,
        password VARCHAR(255) DEFAULT '${DEFAULT_PASSWORD_BCRYPT_HASH}',
        mustChangePassword TINYINT(1) DEFAULT 0,
        lastSeenAt VARCHAR(50) NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 7. Create User Activity Logs Table
    await db.query(`
      CREATE TABLE IF NOT EXISTS user_activity_logs (
        id VARCHAR(50) PRIMARY KEY,
        userId VARCHAR(50) NULL,
        userName VARCHAR(150) NOT NULL,
        userRole VARCHAR(50) NOT NULL,
        action VARCHAR(100) NOT NULL,
        details TEXT,
        module VARCHAR(50) DEFAULT 'SYSTEM',
        ipAddress VARCHAR(50) DEFAULT '127.0.0.1',
        status VARCHAR(20) DEFAULT 'SUCCESS',
        createdAt VARCHAR(50) NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // --- Automated Schema Migration / Repair Block ---
    console.log("🔄 [Bootstrap] Verifying table schemas and performing automatic migrations...");
    await ensureColumnExists(db, "products", "description", "TEXT");
    await ensureColumnExists(db, "products", "weight", "VARCHAR(50)");
    await ensureColumnExists(db, "products", "dimensions", "VARCHAR(50)");
    await ensureColumnExists(db, "products", "coverageInfo", "VARCHAR(150)");
    await ensureColumnExists(db, "products", "isEnabled", "TINYINT(1) DEFAULT 1");

    await ensureColumnExists(db, "agents", "address", "TEXT");
    await ensureColumnExists(db, "agents", "area", "VARCHAR(255)");
    await ensureColumnExists(db, "agents", "territories", "TEXT");
    await ensureColumnExists(db, "agents", "isExportAgent", "TINYINT(1) DEFAULT 0");
    await ensureColumnExists(db, "agents", "isEnabled", "TINYINT(1) DEFAULT 1");
    await ensureColumnExists(db, "agents", "personType", "VARCHAR(20) DEFAULT 'REAL'");
    await ensureColumnExists(db, "agents", "companyName", "VARCHAR(150)");
    await ensureColumnExists(db, "agents", "registrationNumber", "VARCHAR(50)");
    await ensureColumnExists(db, "agents", "economicCode", "VARCHAR(50)");
    await ensureColumnExists(db, "agents", "nationalId", "VARCHAR(50)");
    await ensureColumnExists(db, "agents", "nationalCode", "VARCHAR(50)");

    await ensureColumnExists(db, "shipping_companies", "managerName", "VARCHAR(150)");
    await ensureColumnExists(db, "shipping_companies", "address", "TEXT");
    await ensureColumnExists(db, "shipping_companies", "isEnabled", "TINYINT(1) DEFAULT 1");
    await ensureColumnExists(db, "shipping_companies", "nationalId", "VARCHAR(50)");
    await ensureColumnExists(db, "shipping_companies", "economicCode", "VARCHAR(50)");

    await ensureColumnExists(db, "permanent_drivers", "shippingCompanyId", "VARCHAR(50) NULL");

    await ensureColumnExists(db, "app_users", "username", "VARCHAR(100) NOT NULL UNIQUE");
    await ensureColumnExists(db, "app_users", "fullName", "VARCHAR(150) NOT NULL");
    await ensureColumnExists(db, "app_users", "phoneNumber", "VARCHAR(20) NOT NULL UNIQUE");
    await ensureColumnExists(db, "app_users", "role", "VARCHAR(50) NOT NULL");
    await ensureColumnExists(db, "app_users", "agentCode", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "app_users", "shippingCompanyId", "VARCHAR(100) NULL");
    await ensureColumnExists(db, "app_users", "isEnabled", "TINYINT(1) DEFAULT 1");
    await ensureColumnExists(db, "app_users", "email", "VARCHAR(150) NULL");
    await ensureColumnExists(db, "app_users", "emailVerified", "TINYINT(1) NOT NULL DEFAULT 0");
    await ensureColumnExists(db, "app_users", "emailVerifiedAt", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "app_users", "tokenVersion", "INT NOT NULL DEFAULT 0");
    await ensureColumnExists(db, "app_users", "password", `VARCHAR(255) DEFAULT '${DEFAULT_PASSWORD_BCRYPT_HASH}'`);
    await ensureColumnExists(db, "app_users", "mustChangePassword", "TINYINT(1) DEFAULT 0");
    await ensureColumnExists(db, "app_users", "lastSeenAt", "VARCHAR(50) NULL");

    // Agents table columns
    await ensureColumnExists(db, "agents", "territories", "LONGTEXT NULL");
    await ensureColumnExists(db, "agents", "isExportAgent", "TINYINT(1) DEFAULT 0");
    await ensureColumnExists(db, "agents", "personType", "VARCHAR(20) DEFAULT 'REAL'");
    await ensureColumnExists(db, "agents", "companyName", "VARCHAR(150) NULL");
    await ensureColumnExists(db, "agents", "registrationNumber", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "agents", "economicCode", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "agents", "nationalId", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "agents", "nationalCode", "VARCHAR(50) NULL");
    try {
      await db.query("ALTER TABLE agents MODIFY COLUMN area LONGTEXT NULL");
    } catch (aErr: any) {}

    await ensureColumnExists(db, "orders", "sentToFactoryAt", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "orders", "priorityIndex", "INT DEFAULT 0");
    await ensureColumnExists(db, "orders", "rejectionReason", "TEXT");
    await ensureColumnExists(db, "orders", "vehicleType", "VARCHAR(100) NULL");
    await ensureColumnExists(db, "orders", "driverName", "VARCHAR(100) NULL");
    await ensureColumnExists(db, "orders", "driverPhone", "VARCHAR(20) NULL");
    await ensureColumnExists(db, "orders", "licensePlate", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "orders", "shippingAgency", "VARCHAR(150) NULL");
    await ensureColumnExists(db, "orders", "estimatedArrival", "VARCHAR(100) NULL");
    await ensureColumnExists(db, "orders", "itemsJson", "TEXT NULL");
    await ensureColumnExists(db, "orders", "paymentTrackingCode", "VARCHAR(150) NULL");
    await ensureColumnExists(db, "orders", "paymentReceiptUrl", "LONGTEXT NULL");
    await ensureColumnExists(db, "orders", "paymentReceiptName", "VARCHAR(255) NULL");
    await ensureColumnExists(db, "orders", "buyerName", "VARCHAR(255) NULL");
    await ensureColumnExists(db, "orders", "billOfLadingNumber", "VARCHAR(100) NULL");
    await ensureColumnExists(db, "orders", "shippingCompanyId", "VARCHAR(150) NULL");
    await ensureColumnExists(db, "orders", "isExportOrder", "TINYINT(1) DEFAULT 0");
    await ensureColumnExists(db, "orders", "destinationCountry", "VARCHAR(100) NULL");
    await ensureColumnExists(db, "orders", "deliveryLocationUrl", "TEXT NULL");
    await ensureColumnExists(db, "orders", "hasPendingEdit", "TINYINT(1) DEFAULT 0");
    await ensureColumnExists(db, "orders", "pendingEditData", "TEXT NULL");
    await ensureColumnExists(db, "orders", "warehouseDetails", "LONGTEXT NULL");
    await ensureColumnExists(db, "orders", "securityGateDetails", "LONGTEXT NULL");
    await ensureColumnExists(db, "orders", "exitPermitNumber", "VARCHAR(100) NULL");
    await ensureColumnExists(db, "orders", "loadedPalletsCount", "INT NULL");
    await ensureColumnExists(db, "orders", "weighbridgeNet", "INT NULL");
    await ensureColumnExists(db, "orders", "securitySealNumber", "VARCHAR(100) NULL");

    // products primaryUnit, secondaryUnit, conversionRatio, defaultQuantity, imageUrl
    await ensureColumnExists(db, "products", "primaryUnit", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "products", "secondaryUnit", "VARCHAR(50) NULL");
    await ensureColumnExists(db, "products", "conversionRatio", "DECIMAL(10, 2) NULL");
    await ensureColumnExists(db, "products", "defaultQuantity", "INT NULL DEFAULT 330");
    await ensureColumnExists(db, "products", "imageUrl", "LONGTEXT NULL");

    // Upgrade existing columns to LONGTEXT if they were created with smaller types
    try {
      await db.query("ALTER TABLE products MODIFY COLUMN imageUrl LONGTEXT NULL");
      await db.query("ALTER TABLE products MODIFY COLUMN description LONGTEXT NULL");
      await db.query("ALTER TABLE orders MODIFY COLUMN itemsJson LONGTEXT NULL");
      await db.query("ALTER TABLE orders MODIFY COLUMN pendingEditData LONGTEXT NULL");
      await db.query("ALTER TABLE orders MODIFY COLUMN exactAddress LONGTEXT NULL");
      await db.query("ALTER TABLE orders MODIFY COLUMN notes LONGTEXT NULL");
    } catch (alterErr: any) {
      console.log("ℹ️ [Migration Note] Modify columns:", alterErr.message);
    }

    // High performance database indexes
    await ensureIndexExists(db, "user_activity_logs", "idx_ual_created", "createdAt DESC");
    await ensureIndexExists(db, "orders", "idx_orders_created", "createdAt DESC");
    await ensureIndexExists(db, "orders", "idx_orders_priority", "priorityIndex ASC");
    await ensureIndexExists(db, "orders", "idx_orders_agentcode", "agentCode");
    await ensureIndexExists(db, "orders", "idx_orders_shippingcompany", "shippingCompanyId");
    await ensureIndexExists(db, "order_history", "idx_oh_orderid", "orderId");
    await ensureIndexExists(db, "app_users", "idx_users_username", "username");
    await ensureIndexExists(db, "app_users", "idx_users_phone", "phoneNumber");
    await ensureIndexExists(db, "app_users", "idx_users_email", "email");

    console.log("✅ [Bootstrap] MariaDB tables checked and synchronized successfully!");

    // Seed tables if empty (Development & Test only! Strictly disabled in production)
    if (!isProductionEnvironment()) {
      await seedDatabaseIfEmpty(db);
    } else {
      console.log("🔒 [Bootstrap] Production mode detected: Automatic database seeding is strictly DISABLED.");
      // In production, check if app_users is empty and fail safely without creating insecure accounts
      try {
        const [uRows] = (await db.query("SELECT COUNT(*) as count FROM app_users")) as any[];
        const count = (uRows && uRows[0]?.count !== undefined) ? uRows[0].count : 0;
        if (count === 0) {
          console.error("🚨 [Bootstrap Security Alert] Production database 'app_users' table is completely empty! Manual administrator provisioning is required.");
        }
      } catch (checkErr: any) {
        console.warn("⚠️ [Bootstrap] Unable to verify user count in production:", checkErr.message);
      }
    }

    // Auto-migrate any unhashed passwords in MariaDB
    await migrateDatabasePasswords(db);

    // Mark DB healthy ONLY after DDL, migrations, seeding, and password migration all succeed
    isDbHealthy = true;
    isFallbackMode = false;
    dbMaintenanceError = null;

    // Test Redis connectivity if configured
    const redisClient = getRedisClient();
    if (redisClient) {
      try {
        await Promise.race([
          redisClient.ping(),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), 1500))
        ]);
        console.log("✅ [Bootstrap] Redis connection verified successfully!");
      } catch (err: any) {
        console.warn("⚠️ [Bootstrap] Redis connection test failed or timed out. Continuing without active Redis:", err.message);
      }
    }
  } catch (error: any) {
    writeServerErrorLog("Bootstrap MariaDB", error);

    // If MariaDB was reachable (SELECT 1 succeeded) and bootstrap/seeding failed with a schema or SQL error,
    // NEVER mask it with MockPool or mark the database healthy — propagate cleanly so startup fails safely.
    if (connectivityVerified && !isConnectionError(error)) {
      markDatabaseUnhealthy(error);
      isFallbackMode = false;
      mockPoolInstance = null;
      console.error("❌ [Bootstrap] MariaDB schema/seed error after connection succeeded:", error?.message || error);
      throw error;
    }

    // Requirement 1 & 4: In production, NEVER silently switch to JSON storage. Return controlled maintenance state.
    if (isProductionEnvironment()) {
      console.warn("⚠️ [Bootstrap] MariaDB is offline or unreachable in production. Maintenance mode active:", error.message);
      markDatabaseUnhealthy(error);
      isFallbackMode = false;
      mockPoolInstance = null;
      return;
    }

    // Requirement 2 & 5: In development mode only, allow local JSON mock database mode for developer workflow
    console.info("⚡ [Bootstrap] MariaDB is offline in development. Operating in local JSON mock database mode.");
    try {
      if (pool) {
        await pool.end();
      }
    } catch {}
    pool = null;
    isFallbackMode = true;
    mockPoolInstance = new MockPool();
    seedJsonIfEmpty();
    await migrateDatabasePasswords(mockPoolInstance);
  }
}

export async function seedDatabaseWithConnection(connection: any) {
  const executeSeedStep = async (tableName: string, fn: () => Promise<void>) => {
    try {
      await fn();
    } catch (err: any) {
      console.error(`❌ [Seed] Failed seeding table '${tableName}':`, err?.message || err);
      throw err;
    }
  };

  const dummyProducts = [
    ['prod-1', 'سفال سقف طبرستان (طرح کلاسیک)', 'roofing', 145000, 'عدد', 'مقاومت بسیار بالا در برابر تغییرات جوی و یخبندان، عایق حرارتی و رطوبتی فوق‌العاده با لعاب طبیعی.', '۳.۱ کیلوگرم', '۳۰ × ۴۲ سانتی‌متر', '۱۴ عدد در هر مترمربع', 1],
    ['prod-2', 'آجر سفال ۱۰ سانتی طبرستان (تیغه)', 'bricks', 3400, 'قالب', 'جهت دیوارهای داخلی و فضاهای کم‌عرض، پخت با کوره تمام اتوماتیک هافمن و ابعاد کاملاً گونیا.', '۲.۲ کیلوگرم', '۱۰ × ۲۰ × ۲۰ سانتی‌متر', '۲۵ قالب در هر مترمربع تیغه', 1],
    ['prod-3', 'آجر سفال ۱۵ سانتی درجه یک طبرستان', 'bricks', 4800, 'قالب', 'بهترین گزینه برای دیوارهای خارجی باغ، ویلا و آپارتمان جهت عایق‌بندی صوتی و حرارتی پیشرفته.', '۳.۳ کیلوگرم', '۱۵ × ۲۰ × ۲۰ سانتی‌متر', '۲۵ قالب در هر مترمربع دیوار', 1],
    ['prod-4', 'آجر نما نسوز سموتی طبرستان', 'facade', 12500, 'قالب', 'مقاومت حرارتی بیش از ۱۲۰۰ درجه سانتی‌گراد، رنگ ثابت و مقاوم در برابر باران‌های اسیدی و شوره‌زدگی.', '۰.۸ کیلوگرم', '۵.۵ × ۲.۵ × ۲۶ سانتی‌متر', '۴۰ قالب در هر مترمربع با بندکشی', 1],
    ['prod-5', 'تیغه سفال سقفی ۲۵ طبرستان (بلوک سقفی)', 'bricks', 9500, 'قالب', 'تولید شده با رس مرغوب شسته شده، مقاومت فشاری بالا و ایده آل برای سقف‌های تیرچه بلوک صنعتی.', '۷.۵ کیلوگرم', '۲۵ × ۲۰ × ۴۰ سانتی‌متر', '۱۰ قالب در هر مترمربع سقف', 1]
  ];
  await executeSeedStep("products", async () => {
    for (const p of dummyProducts) {
      await connection.query(
        "INSERT INTO products (id, name, category, pricePerUnit, unit, description, weight, dimensions, coverageInfo, isEnabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE id = id",
        p
      );
    }
  });

  const dummyAgents = [
    ['ag-1', 'آقای حمیدرضا احمدی', 'نمایندگی تهران (احمدی)', 'AG-9081', '09121111111', 'تهران، ابتدای جاده قدیم کرج، مجتمع تجاری پایتخت، پلاک ۱۲', 'کل استان تهران؛ کل استان البرز', JSON.stringify([{ province: 'تهران', allCities: true }, { province: 'البرز', allCities: true }]), 1, 1],
    ['ag-2', 'آقای علیرضا رجایی', 'نمایندگی اصفهان (رجایی)', 'AG-6055', '09132222222', 'اصفهان، بلوار فرودگاه، نرسیده به شهرک صنعتی جی، پلاک ۴۶', 'کل استان اصفهان؛ کل استان یزد', JSON.stringify([{ province: 'اصفهان', allCities: true }, { province: 'یزد', allCities: true }]), 0, 1],
    ['ag-3', 'آقای سهراب پوربخش', 'نمایندگی رشت (پوربخش)', 'AG-2019', '09113333333', 'گیلان، رشت، کیلومتر ۵ جاده انزلی، جنب انبار فومن‌شیمی', 'کل استان گیلان؛ کل استان مازندران', JSON.stringify([{ province: 'گیلان', allCities: true }, { province: 'مازندران', allCities: true }]), 0, 1],
    ['ag-4', 'آقای کریم نمازی', 'نمایندگی شیراز (نمازی)', 'AG-7023', '09174444444', 'فارس، شیراز، بلوار امیرکبیر، روبروی باغ جنت، مجتمع سفال', 'کل استان فارس؛ کل استان بوشهر', JSON.stringify([{ province: 'فارس', allCities: true }, { province: 'بوشهر', allCities: true }]), 0, 1]
  ];
  await executeSeedStep("agents", async () => {
    for (const a of dummyAgents) {
      await connection.query(
        "INSERT INTO agents (id, fullName, alias, agentCode, phoneNumber, address, area, territories, isExportAgent, isEnabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE id = id",
        a
      );
    }
  });

  const dummyShipping = [
    ['sc-1', 'باربری ترانزیت شمال طبرستان', 'SC-101', '01133334444', 'آقای رستمی', 'ساری، جاده نکا، کیلومتر ۵، جنب کارخانه طبرستان', 1],
    ['sc-2', 'باربری زاینده‌رود طبرستان', 'SC-102', '01133335555', 'آقای صادقی', 'اصفهان، شهرک صنعتی جی، خیابان چهارم، پایانه باربری زاینده‌رود', 1],
    ['sc-3', 'اتوبار کاسپین طبرستان', 'SC-103', '01133336666', 'آقای احمدی', 'رشت، جاده انزلی، جنب پایانه حمل و نقل کاسپین', 1]
  ];
  await executeSeedStep("shipping_companies", async () => {
    for (const s of dummyShipping) {
      await connection.query(
        "INSERT INTO shipping_companies (id, name, code, phoneNumber, managerName, address, isEnabled) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE id = id",
        s
      );
    }
  });

  const dummyDrivers = [
    ['drv-1', 'کریم قنبری', '09117772222', '۵۴ ع ۸۹۲ ایران ۷۲', 'تریلی ۱۸ چرخ لبه‌دار', 'باربری ترانزیت شمال', 'sc-1', '2081234567', '3849201', 1],
    ['drv-2', 'غلامرضا صادقی', '09139998888', '۷۲ ب ۵۵۱ ایران ۵۳', 'کامیون جفت ۱۰ تن', 'باربری زاینده‌رود', 'sc-2', '1289876543', '4920183', 1],
    ['drv-3', 'مرتضی حسینی', '09112223344', '۳۶ ج ۱۴۵ ایران ۶۲', 'خاور مسقف', 'باربری کاسپین', 'sc-3', '2093344556', '1092837', 1],
    ['drv-4', 'جواد علوی', '09112523456', '۶۲ ع ۴۸۱ ایران ۷۲', 'تریلی ۱۸ چرخ لبه‌دار', 'باربری ترانزیت طبرستان', 'sc-1', '2089988771', '5544332', 1]
  ];
  await executeSeedStep("permanent_drivers", async () => {
    for (const d of dummyDrivers) {
      await connection.query(
        "INSERT INTO permanent_drivers (id, driverName, driverPhone, licensePlate, vehicleType, shippingAgency, shippingCompanyId, nationalCode, smartCardNumber, isEnabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE id = id",
        d
      );
    }
  });

  const dummyUsers = [
    ['usr-0', 'admin', 'ادمین ارشد نرم‌افزار', '09120000000', 'SYSTEM_ADMIN', null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-1', 'manager', 'آقای احمدی (مدیر بازرگانی)', '09121111111', 'SALES_MANAGER', null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-2', 'rep_tehran', 'آقای حمیدرضا احمدی', '09120000001', 'REPRESENTATIVE', 'AG-9081', null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-3', 'rep_esfahan', 'آقای علیرضا رجایی', '09130000002', 'REPRESENTATIVE', 'AG-6055', null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-4', 'rep_rasht', 'آقای سهراب پوربخش', '09110000003', 'REPRESENTATIVE', 'AG-2019', null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-5', 'rep_shiraz', 'آقای کریم نمازی', '09170000004', 'REPRESENTATIVE', 'AG-7023', null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-6', 'factory', 'مسئول اول فروش کارخانه', '09110000005', 'FACTORY_TRANSPORT', null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-62', 'factory2', 'مسئول دوم فروش کارخانه', '09110000007', 'FACTORY_TRANSPORT', null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-7', 'shipping_transit', 'باربری ترانزیت طبرستان', '09110000006', 'SHIPPING_COMPANY', null, 'sc-1', 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-72', 'shipping_zayandeh', 'باربری زاینده‌رود طبرستان', '09130000007', 'SHIPPING_COMPANY', null, 'sc-2', 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-8', 'warehouse', 'مسئول انبار محصول (بارگیری و صدور حواله)', '09110000008', 'PRODUCT_WAREHOUSE', null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH],
    ['usr-9', 'security_gate', 'افسر انتظامات و حراست گیت خروج', '09110000009', 'SECURITY_GATE', null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH]
  ];
  await executeSeedStep("app_users", async () => {
    for (const u of dummyUsers) {
      await connection.query(
        "INSERT INTO app_users (id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, isEnabled, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE id = id",
        u
      );
    }
  });
}

export async function seedDatabaseIfEmpty(db: mysql.Pool) {
  if (isProductionEnvironment()) {
    console.warn("🚨 [Security Guard] seedDatabaseIfEmpty called in production: execution aborted.");
    return;
  }

  const runInTransaction = async (fn: (connection: any) => Promise<void>) => {
    if (typeof (db as any).getConnection === "function") {
      const connection = await (db as any).getConnection();
      try {
        if (typeof connection.beginTransaction === "function") {
          await connection.beginTransaction();
        }
        await fn(connection);
        if (typeof connection.commit === "function") {
          await connection.commit();
        }
      } catch (txErr) {
        if (typeof connection.rollback === "function") {
          try {
            await connection.rollback();
          } catch {}
        }
        throw txErr;
      } finally {
        if (typeof connection.release === "function") {
          connection.release();
        }
      }
    } else {
      await fn(db);
    }
  };

  try {
    const getCount = async (tableName: string): Promise<number> => {
      const [rows] = (await db.query(`SELECT COUNT(*) as count FROM ${tableName}`)) as any[];
      return rows && rows[0]?.count !== undefined ? Number(rows[0].count) : 0;
    };

    const [prodCount, agentCount, scCount, driverCount, userCount] = await Promise.all([
      getCount("products"),
      getCount("agents"),
      getCount("shipping_companies"),
      getCount("permanent_drivers"),
      getCount("app_users")
    ]);

    if (prodCount === 0 || agentCount === 0 || scCount === 0 || driverCount === 0 || userCount === 0) {
      console.log("🌱 [Seed] Seeding default database entities inside transaction...");
      await runInTransaction(async (connection) => {
        await seedDatabaseWithConnection(connection);
      });
    } else {
      // Ensure essential system/operational accounts exist idempotently inside a single transaction on a single connection
      const requiredAccounts: Array<{
        id: string;
        username: string;
        role: string;
        row: [string, string, string, string, string, null, null, number, string];
      }> = [
        {
          id: "usr-0",
          username: "admin",
          role: "SYSTEM_ADMIN",
          row: ["usr-0", "admin", "ادمین ارشد نرم‌افزار", "09120000000", "SYSTEM_ADMIN", null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH]
        },
        {
          id: "usr-8",
          username: "warehouse",
          role: "PRODUCT_WAREHOUSE",
          row: ["usr-8", "warehouse", "مسئول انبار محصول (بارگیری و صدور حواله)", "09110000008", "PRODUCT_WAREHOUSE", null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH]
        },
        {
          id: "usr-9",
          username: "security_gate",
          role: "SECURITY_GATE",
          row: ["usr-9", "security_gate", "افسر انتظامات و حراست گیت خروج", "09110000009", "SECURITY_GATE", null, null, 1, DEFAULT_PASSWORD_BCRYPT_HASH]
        }
      ];

      await runInTransaction(async (connection) => {
        for (const acc of requiredAccounts) {
          const [existingRows] = (await connection.query(
            "SELECT id, username, role, phoneNumber FROM app_users WHERE id = ? OR username = ?",
            [acc.id, acc.username]
          )) as any[];

          if (Array.isArray(existingRows) && existingRows.length > 1) {
            throw new Error(
              `Incompatible user recovery conflict for '${acc.id}' (${acc.username}/${acc.role}): multiple conflicting records match id or username.`
            );
          }

          if (Array.isArray(existingRows) && existingRows.length === 1) {
            const existing = existingRows[0];
            if (existing.id === acc.id && existing.username === acc.username && existing.role === acc.role) {
              continue; // Compatible account already exists; preserve existing data untouched
            }
            throw new Error(
              `Incompatible user recovery conflict for '${acc.id}' (${acc.username}/${acc.role}): found conflicting record (id='${existing.id}', username='${existing.username}', role='${existing.role}').`
            );
          }

          console.log(`🛡️ [Seed] Auto-inserting missing required user '${acc.username}' (${acc.role}) in SQL database...`);
          try {
            await connection.query(
              "INSERT INTO app_users (id, username, fullName, phoneNumber, role, agentCode, shippingCompanyId, isEnabled, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE id = id",
              acc.row
            );
          } catch (insertErr: any) {
            if (insertErr?.code !== "ER_DUP_ENTRY") {
              throw insertErr;
            }
          }

          // Strictly verify expected user exists with matching id, username, and role after insert or unique-key collision
          const [verifiedRows] = (await connection.query(
            "SELECT id, username, role FROM app_users WHERE id = ? OR username = ?",
            [acc.id, acc.username]
          )) as any[];

          const verified = Array.isArray(verifiedRows) && verifiedRows.length === 1 ? verifiedRows[0] : null;
          if (!verified || verified.id !== acc.id || verified.username !== acc.username || verified.role !== acc.role) {
            throw new Error(
              `Required user verification failed for '${acc.id}' (${acc.username}/${acc.role}) after insert or unique key collision (found: ${JSON.stringify(verifiedRows || [])}).`
            );
          }
        }
      });
    }

    console.log("🌱 [Seed] Database tables successfully synchronized!");
  } catch (err: any) {
    console.error("❌ [Seed] Error during seeding database:", err?.message || err);
    throw err;
  }
}

// --- Activity Logging & Telemetry Helpers ---
const inMemoryActivityLogs: any[] = [];

export function clearInMemoryActivityLogs() {
  inMemoryActivityLogs.length = 0;
}

const WORTHLESS_LOG_ACTIONS = new Set([
  'خروج از سیستم',
  'ورود به سیستم',
  'فعالسازی شبیه‌ساز',
  'غیرفعالسازی و پنهان‌سازی شبیه‌ساز',
  'ثبت/بروزرسانی لوکیشن تخلیه بار',
  'تغییر وضعیت فعال‌سازی محصول',
  'تغییر وضعیت نمایندگی',
  'تغییر وضعیت باربری',
  'تغییر وضعیت راننده',
  'تغییر وضعیت حساب کاربر',
  'بررسی وضعیت'
]);

export async function logUserActivity(log: {
  userId?: string;
  userName: string;
  userRole: string;
  action: string;
  details?: string;
  module?: string;
  ipAddress?: string;
  status?: 'SUCCESS' | 'WARNING' | 'ERROR';
}) {
  // 1. Immediately drop trivial or noise actions with zero overhead
  if (!log?.action || WORTHLESS_LOG_ACTIONS.has(log.action.trim())) {
    return;
  }

  const logEntry = {
    id: `act-${Date.now()}-${Math.floor(Math.random()*1000)}`,
    userId: log.userId || 'SYSTEM',
    userName: log.userName || 'ناشناس',
    userRole: log.userRole || 'USER',
    action: log.action,
    details: log.details || '',
    module: log.module || 'GENERAL',
    ipAddress: log.ipAddress || '127.0.0.1',
    status: log.status || 'SUCCESS',
    createdAt: new Date().toISOString()
  };

  // Keep a compact in-memory ring-buffer
  inMemoryActivityLogs.unshift(logEntry);
  if (inMemoryActivityLogs.length > 100) inMemoryActivityLogs.pop();

  // Only execute database query if connected to physical database
  if (!isFallbackMode) {
    try {
      const db = getDbPool();
      await db.query(`
        INSERT INTO user_activity_logs (id, userId, userName, userRole, action, details, module, ipAddress, status, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        logEntry.id, logEntry.userId, logEntry.userName, logEntry.userRole,
        logEntry.action, logEntry.details, logEntry.module, logEntry.ipAddress,
        logEntry.status, logEntry.createdAt
      ]);
    } catch {
      // Silently ignore logging failures to avoid slowing down operational requests
    }
  }
}

export async function getUserActivityLogs(limit = 100): Promise<any[]> {
  if (!isFallbackMode) {
    try {
      const db = getDbPool();
      const [rows] = await db.query(`
        SELECT * FROM user_activity_logs ORDER BY createdAt DESC LIMIT ?
      `, [limit]) as any[];
      if (Array.isArray(rows) && rows.length > 0) {
        return rows;
      }
    } catch (err: any) {
      if (isProductionEnvironment()) {
        throw new DatabaseMaintenanceError("Cannot retrieve activity logs while database is offline.");
      }
      // Silently fall back to in-memory logs in development only
    }
  }
  if (isProductionEnvironment()) {
    return [];
  }
  return inMemoryActivityLogs.slice(0, limit);
}
